module.exports = {    
    plugins: [
      [
        // '@babel/plugin-transform-modules-commonjs',
        // {
        //   strictMode: false,
        //   allowTopLevelThis: true,
        //   loose: true,
        // },
        'transform-object-rest-spread',
        'module-resolver',
        {
          root: ['./src'],
          extensions: ['.js', '.ts', '.tsx', '.json'],
          alias: {
            'test/*': './test/',
          },
        },
      ],
    ],
    "env": {
      "production": {
        "plugins": ["transform-remove-console"]
      }
    }
  };
  