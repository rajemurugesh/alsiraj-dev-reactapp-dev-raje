import React, { Suspense } from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import * as serviceWorker from './serviceWorker';
import AppRoutes from 'AppRoutes';
import { Provider } from 'react-redux';
import store from 'appredux/configureStore';
import "./ii8n";

ReactDOM.render(
  <React.Fragment>
    <Provider store={store}>
      <div className="wrapper">
        <Suspense fallback="loading">
          <AppRoutes></AppRoutes>
        </Suspense>
      </div>
    </Provider>
  </React.Fragment>,
  document.getElementById('page-wraper')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
