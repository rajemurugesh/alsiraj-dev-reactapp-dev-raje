interface ConfigOptions{
    TenantId?: string,
    LoginAppClientId?: string,
    RegisterAppClientId?: string,
    AppUrl: string,
    FacebookAppId: string
}

export const Config: ConfigOptions = {
    TenantId: process.env.REACT_APP_AZAPP_TENANT_ID,
    LoginAppClientId: process.env.REACT_APP_AZAPP_LOGIN_CLIENT_ID,
    RegisterAppClientId: process.env.REACT_APP_AZAPP_REGISTER_CLIENT_ID,
    AppUrl: window.location.protocol+"//"+window.location.host,
    FacebookAppId: process.env.REACT_APP_FACEBOOK_APP_ID!
}