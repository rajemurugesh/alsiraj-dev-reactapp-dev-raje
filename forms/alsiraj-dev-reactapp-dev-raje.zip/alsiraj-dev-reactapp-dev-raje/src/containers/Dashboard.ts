import { connect, ConnectedProps } from 'react-redux';
import { RootState } from 'appredux/configureStore';
import LoginScreen from 'screens/Login';
import { User, ValidateForm, SubmitloginBtnClicked, ResetForm, SubmitLogin, Skill, SubmitSkill, ValidateSkillForm, SubmitSkillBtnClicked, GetSkillList } from 'appredux/modules/Login/Login';
import DashBoardScreen from 'screens/DashBoard';

const mapStateToProps = ( state : RootState ) => ({
    session: state.Session,  
    dashboard: state.LoginReducers.Login,
});

const mapDispatchToProps = {
    SubmitLogin: (params: User) => SubmitLogin(params),
    ValidateForm: (params: User) => ValidateForm(params),
    SubmitloginBtnClicked: (params:boolean) => SubmitloginBtnClicked(params),
    ResetForm: () => ResetForm(),
    SubmitSkill: (params: Skill) => SubmitSkill(params),
    ValidateSkillForm: (params: Skill) => ValidateSkillForm(params),
    SubmitSkillBtnClicked: (params:boolean) => SubmitSkillBtnClicked(params),
    GetSkillList: (params: any) => GetSkillList(params),

    
}


const connector = connect(
    mapStateToProps,
    mapDispatchToProps
)

export type DashBoardScreenPropsFromRedux = ConnectedProps<typeof connector>;

export default connector(DashBoardScreen);