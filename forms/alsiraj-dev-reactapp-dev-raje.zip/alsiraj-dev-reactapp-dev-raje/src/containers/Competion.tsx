import { connect, ConnectedProps } from 'react-redux';
import { RootState } from 'appredux/configureStore';
import { Competition } from 'appredux/model/common';
import CompetionScreen from 'screens/Competion';
import { CompetitionResetForm, CompetitionSubmitBtnClicked, CompetitionValidateForm, fileUpload, SubmitCompetitionation } from 'appredux/modules/Login/Competition';

const mapStateToProps = ( state : RootState ) => ({
    competition: state.LoginReducers.Competition,
});

const mapDispatchToProps = {
    SubmitCompetitionation: (params: Competition) => SubmitCompetitionation(params),
    CompetitionValidateForm: (params: Competition) => CompetitionValidateForm(params),
    CompetitionSubmitBtnClicked:(params: boolean)=> CompetitionSubmitBtnClicked(params),
    CompetitionResetForm: () => CompetitionResetForm(),
    fileUpload:(params:any)=>fileUpload(params)
}


const connector = connect(
    mapStateToProps,
    mapDispatchToProps
)

export type CompetionScreenPropsFromRedux = ConnectedProps<typeof connector>;

export default connector(CompetionScreen);