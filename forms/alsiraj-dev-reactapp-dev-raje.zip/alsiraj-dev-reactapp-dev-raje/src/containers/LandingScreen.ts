import { connect, ConnectedProps } from 'react-redux';
import { RootState } from 'appredux/configureStore';
import LandingScreen from 'screens/LandingScreen';

const mapStateToProps = ( state : RootState ) => ({
    session: state.Session,  
});

const mapDispatchToProps = {
}

declare namespace JSX {
    interface IntrinsicElements {
        marque: any
    }
}


const connector = connect(
    mapStateToProps,
    mapDispatchToProps
)

export type LandingScreenPropsFromRedux = ConnectedProps<typeof connector>;

export default connector(LandingScreen);