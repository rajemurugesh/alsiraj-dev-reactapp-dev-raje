import { connect, ConnectedProps } from 'react-redux';
import { RootState } from 'appredux/configureStore';
import OurVisionScreen from 'screens/Ourvision';

const mapStateToProps = ( state : RootState ) => ({
    session: state.Session,  
});

const mapDispatchToProps = {
}


const connector = connect(
    mapStateToProps,
    mapDispatchToProps
)

export type OurVisionScreenPropsFromRedux = ConnectedProps<typeof connector>;

export default connector(OurVisionScreen);