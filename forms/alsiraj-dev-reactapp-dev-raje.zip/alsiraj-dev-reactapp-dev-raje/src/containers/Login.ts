import { connect, ConnectedProps } from 'react-redux';
import { RootState } from 'appredux/configureStore';
import LoginScreen from 'screens/Login';
import { User, ValidateForm, SubmitloginBtnClicked, ResetForm, SubmitLogin } from 'appredux/modules/Login/Login';
import { RegisterUser } from 'appredux/model/common';
import { SubmitRegisteration, RegUserValidateForm, RegUserSubmitBtnClicked, RegUserResetForm } from 'appredux/modules/Login/SignUp';

const mapStateToProps = ( state : RootState ) => ({
    login: state.LoginReducers.Login,
    register: state.LoginReducers.SignUp,
});

const mapDispatchToProps = {
    SubmitLogin: (params: User) => SubmitLogin(params),
    ValidateForm: (params: User) => ValidateForm(params),
    SubmitloginBtnClicked: (params:boolean) => SubmitloginBtnClicked(params),
    ResetForm: () => ResetForm(),
    SubmitUserDetails: (params: RegisterUser) => SubmitRegisteration(params),
    RegUserValidateForm: (params: RegisterUser) => RegUserValidateForm(params),
    RegUserSubmitBtnClicked:(params: boolean)=> RegUserSubmitBtnClicked(params),
    RegUserResetForm: () => RegUserResetForm(),
}


const connector = connect(
    mapStateToProps,
    mapDispatchToProps
)

export type LoginScreenPropsFromRedux = ConnectedProps<typeof connector>;

export default connector(LoginScreen);