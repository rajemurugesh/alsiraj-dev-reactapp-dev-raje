import { connect, ConnectedProps } from 'react-redux';
import { RootState } from 'appredux/configureStore';
import ContactScreen from 'screens/Contact';

const mapStateToProps = ( state : RootState ) => ({
    session: state.Session,  
});

const mapDispatchToProps = {
}


const connector = connect(
    mapStateToProps,
    mapDispatchToProps
)

export type ContactScreenPropsFromRedux = ConnectedProps<typeof connector>;

export default connector(ContactScreen);