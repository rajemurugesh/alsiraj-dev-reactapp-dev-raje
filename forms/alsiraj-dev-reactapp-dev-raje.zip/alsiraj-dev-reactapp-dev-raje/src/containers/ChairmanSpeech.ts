import { connect, ConnectedProps } from 'react-redux';
import { RootState } from 'appredux/configureStore';
import ChairmanSpeechScreen from 'screens/Chairmanspeech';

const mapStateToProps = ( state : RootState ) => ({
    session: state.Session,  
});

const mapDispatchToProps = {
}


const connector = connect(
    mapStateToProps,
    mapDispatchToProps
)

export type ChairmanSpeechScreenPropsFromRedux = ConnectedProps<typeof connector>;

export default connector(ChairmanSpeechScreen);