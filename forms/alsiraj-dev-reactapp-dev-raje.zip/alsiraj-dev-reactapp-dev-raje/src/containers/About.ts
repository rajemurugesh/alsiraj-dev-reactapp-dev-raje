import { connect, ConnectedProps } from 'react-redux';
import { RootState } from 'appredux/configureStore';
import AboutScreen from 'screens/About';

const mapStateToProps = ( state : RootState ) => ({
    session: state.Session,  
});

const mapDispatchToProps = {
}


const connector = connect(
    mapStateToProps,
    mapDispatchToProps
)

export type AboutScreenPropsFromRedux = ConnectedProps<typeof connector>;

export default connector(AboutScreen);