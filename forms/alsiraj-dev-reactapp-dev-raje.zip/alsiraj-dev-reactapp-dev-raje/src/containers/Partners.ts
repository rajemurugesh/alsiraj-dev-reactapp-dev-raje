import { connect, ConnectedProps } from 'react-redux';
import { RootState } from 'appredux/configureStore';
import PartnersScreen from 'screens/Partners';

const mapStateToProps = ( state : RootState ) => ({
    session: state.Session,  
});

const mapDispatchToProps = {
}


const connector = connect(
    mapStateToProps,
    mapDispatchToProps
)

export type PartnersScreenPropsFromRedux = ConnectedProps<typeof connector>;

export default connector(PartnersScreen);