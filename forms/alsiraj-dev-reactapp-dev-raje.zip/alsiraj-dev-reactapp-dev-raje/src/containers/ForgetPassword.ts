import { connect, ConnectedProps } from 'react-redux';
import { RootState } from 'appredux/configureStore';
import ContactScreen from 'screens/Contact';
import ForgetPasswordScreen from 'screens/ForgetPassword';

const mapStateToProps = ( state : RootState ) => ({
    session: state.Session,  
});

const mapDispatchToProps = {
}


const connector = connect(
    mapStateToProps,
    mapDispatchToProps
)

export type ForgetPasswordScreenPropsFromRedux = ConnectedProps<typeof connector>;

export default connector(ForgetPasswordScreen);