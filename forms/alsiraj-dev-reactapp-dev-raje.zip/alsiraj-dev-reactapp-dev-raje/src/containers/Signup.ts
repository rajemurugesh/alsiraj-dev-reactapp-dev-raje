import { connect, ConnectedProps } from 'react-redux';
import { RootState } from 'appredux/configureStore';
import SignupScreen from 'screens/Signup';
import { RegisterUser } from 'appredux/model/common';
import { SubmitRegisteration, RegUserValidateForm, RegUserSubmitBtnClicked, RegUserResetForm, fileUpload } from 'appredux/modules/Login/SignUp';

const mapStateToProps = ( state : RootState ) => ({
    register: state.LoginReducers.SignUp,
});

const mapDispatchToProps = {
    SubmitUserDetails: (params: RegisterUser) => SubmitRegisteration(params),
    RegUserValidateForm: (params: RegisterUser) => RegUserValidateForm(params),
    RegUserSubmitBtnClicked:(params: boolean)=> RegUserSubmitBtnClicked(params),
    RegUserResetForm: () => RegUserResetForm(),
    fileUpload:(params:any)=>fileUpload(params)
}


const connector = connect(
    mapStateToProps,
    mapDispatchToProps
)

export type SignupScreenPropsFromRedux = ConnectedProps<typeof connector>;

export default connector(SignupScreen);