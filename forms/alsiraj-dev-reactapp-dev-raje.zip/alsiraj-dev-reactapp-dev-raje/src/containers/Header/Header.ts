import { connect, ConnectedProps } from 'react-redux';
import Header from 'components/header';
import { RootState } from 'appredux/configureStore';
import { Logout } from 'appredux/modules/Header/Header';

const mapStateToProps = ( state : RootState ) => ({
    session: state.Session,
});

const mapDispatchToProps = {
    Logout:()=>Logout(),
}

const connector = connect(
    mapStateToProps,
    mapDispatchToProps
)

export type HeaderPropsFromRedux = ConnectedProps<typeof connector>;

export default connector(Header);