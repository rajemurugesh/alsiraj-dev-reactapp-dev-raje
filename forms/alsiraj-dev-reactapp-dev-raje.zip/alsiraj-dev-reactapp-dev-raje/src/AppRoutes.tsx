import React, { Component } from "react";
import { Switch, BrowserRouter, Route } from "react-router-dom";
import AboutScreen from "./containers/About";
import LandingScreen from "./containers/LandingScreen";
import ChairmanSpeechScreen from "./containers/ChairmanSpeech";
import OurVisionScreen from "./containers/OurVision";
import PartnersScreen from "./containers/Partners";
import ContactScreen from "./containers/Contact";
import LoginScreen from "./containers/Login";
import SignupScreen from "./containers/Signup";
import ForgetPasswordScreen from "./containers/ForgetPassword";
import DashBoardScreen from "./containers/Dashboard";
import CompetionScreen from "./containers/Competion";
import LandingContentScreen from "./containers/LandingContent";











interface IProps {
    
}

interface IState{

}

export default class AppRoutes extends Component<IProps,IState>{
    constructor(props: any) {
        super(props);
    }
    render(){
        return(
            <BrowserRouter basename={'/'}>
                <Switch>
                <Route exact path={`${process.env.PUBLIC_URL}/about`}  render={(props:any)=> <AboutScreen {...props}></AboutScreen>}></Route>
                <Route exact path={`${process.env.PUBLIC_URL}/chairmanspeech`}  render={(props:any)=> <ChairmanSpeechScreen {...props}></ChairmanSpeechScreen>}></Route>
                <Route exact path={`${process.env.PUBLIC_URL}/ourvision`}  render={(props:any)=> <OurVisionScreen {...props}></OurVisionScreen>}></Route>
                <Route exact path={`${process.env.PUBLIC_URL}/partners`}  render={(props:any)=> <PartnersScreen {...props}></PartnersScreen>}></Route>
                <Route exact path={`${process.env.PUBLIC_URL}/landingcontent`}  render={(props:any)=> <LandingContentScreen {...props}></LandingContentScreen>}></Route>
                <Route exact path={`${process.env.PUBLIC_URL}/contact`}  render={(props:any)=> <ContactScreen {...props}></ContactScreen>}></Route>
                <Route exact path={`${process.env.PUBLIC_URL}/login`}  render={(props:any)=> <LoginScreen {...props}></LoginScreen>}></Route>
                <Route exact path={`${process.env.PUBLIC_URL}/signup`}  render={(props:any)=> <SignupScreen {...props}></SignupScreen>}></Route>
                <Route exact path={`${process.env.PUBLIC_URL}/reset`}  render={(props:any)=> <ForgetPasswordScreen {...props}></ForgetPasswordScreen>}></Route>
                <Route exact path={`${process.env.PUBLIC_URL}/dashboard`}  render={(props:any)=> <DashBoardScreen {...props}></DashBoardScreen>}></Route>
                <Route exact path={`${process.env.PUBLIC_URL}/participation`}  render={(props:any)=> <CompetionScreen {...props}></CompetionScreen>}></Route>


                <Route exact path={`${process.env.PUBLIC_URL}/`}  render={(props:any)=> <LandingScreen {...props}></LandingScreen>}></Route>
                </Switch>
            </BrowserRouter>
        );
    }
}