import React from 'react'
import SocialLogin from 'react-social-login'

class SocialButton extends React.Component {

    render() {
        return (
            <button style={{alignItems:'center'}} class={this.props.facebook ? "fb btn btn-md " :"google btn btn-md "}  onClick={this.props.triggerLogin} {...this.props}>
                <div>

              
               {
                  
                   <i style={{border:0,padding:0,color:'#fff',fontSize:25,marginTop:5}} class={ this.props.facebook ?  " bx bxl-facebook-circle" :"bx bxl-google"}></i>

               } 
              { this.props.children }
              </div>
            </button>
        );
    }
}

export default SocialLogin(SocialButton);