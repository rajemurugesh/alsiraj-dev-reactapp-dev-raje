import React, { Component } from 'react';
import { Link } from 'react-router-dom';

interface IProps{
    navigation?: any
}

export default class Footer extends Component<IProps>{
    scrollToTop = () => {
        window.jQuery('html, body').animate({ scrollTop: 0 }, 2000);
    }
      render(){
        return (
            <React.Fragment>
            {/*<!--Footer Section-->*/}
            <footer id="footer">

    
    <div className="container">
      <div className="copyright">
        &copy; 2020 by <strong><span> Al-Siraj Computer Design</span></strong>
      </div>
    </div>
  </footer>

  
            {/*<!-- End Footer Section-->*/}
            <Link to="#" onClick={this.scrollToTop} className="back-to-top">
                <i className="icofont-simple-up"></i>
            </Link>
            </React.Fragment>
        );
    }
}