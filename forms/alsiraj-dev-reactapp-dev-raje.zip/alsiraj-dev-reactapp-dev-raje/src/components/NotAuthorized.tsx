import React, { Component } from 'react';
import { Link } from 'react-router-dom';

interface IProps {
    navigation?: any,
    authenticated?: boolean
}

export default class NotAuthorized extends Component<IProps>{
    render() {
        return (
            <React.Fragment>

                <div className="wrapper">
                    <section id="intro" className="intro">
                        <div className="mt-60 bg-image parallax parallax-background2">
                            <div className="full-screen-intro container" style={{ minHeight: '250px' }}>
                                <div className="intro-content">{
                                    this.props.authenticated === true
                                        ?
                                        <div className="intro-content-inner">
                                            <h1 className="large mb-25">not authorized to access</h1>
                                            <p className="lead content-wd650">
                                                Your trail period has expired!
                              <br />
                                            </p>
                                            <br />
                                            <a href={`${process.env.PUBLIC_URL}/subscribe`} className="btn btn-md btn-black">SUBSCRIBE</a>
                                        </div> :

                                        <div className="intro-content-inner">
                                            <h1 className="large mb-25">your not authorized to access this page</h1>
                                            <p className="lead content-wd650">
                                            Please sign in and access It.
                           <br />
                                            </p>
                                            <br />
                                            <a href={`#`} className="btn btn-md btn-black">Sign in</a>
                                        </div>
                                }

                                </div>
                            </div>
                        </div>
                    </section>
                    <a className="scroll-top">
                        <i className="fa fa-angle-double-up"></i>
                    </a>

                </div>
            </React.Fragment>
        );
    }
}