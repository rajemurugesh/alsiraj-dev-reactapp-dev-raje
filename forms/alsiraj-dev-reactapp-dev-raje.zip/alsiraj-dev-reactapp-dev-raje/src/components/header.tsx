import React, { Component, useState } from 'react';
import { HeaderPropsFromRedux } from 'containers/Header/Header';
import { Link, NavLink } from 'react-router-dom';
import StorageManagement from 'utils/StorageManagement';
import i18next from "i18next";
import { useTranslation, withTranslation } from 'react-i18next';

import Select from "react-select";
import { width } from '@material-ui/system';
import { Switch } from '@material-ui/core';

interface IProps {
  navLinkclassNameName?: string,
  authenticated?: boolean,
  t?: any
}
interface IState {
  userName: any,
  AppUser: any,
  UserId: any,
  lang: any
}

type Props = HeaderPropsFromRedux & IProps;
export default withTranslation('default')(class Header extends Component<Props, IState>{
  intervalTimer: any;
  constructor(props: Props) {
    super(props);
    this.intervalTimer = null;
    this.state = {
      userName: '',
      AppUser: '',
      UserId: '',
      lang: { label: 'English', value: "en" }
    }

  }

  async componentDidMount() {
    let userData = await StorageManagement.getUserData();
    if (userData) {
      this.setState({
        userName: userData?.UserName!,
        AppUser: userData?.AppUser!,
        UserId: userData?.UserId!,
      });
    }
  }

  async componentDidUpdate() {

  }

  componentWillUnmount() {

  }

  logout() {
    this.props.Logout();
  }

  async ProceedLogout() {
    await StorageManagement.deleteUserSession();
    window.location.href = `${process.env.REACT_APP_URL}`;
  }

  drowpDownChange = (event: any, type: string) => {
    // debugger
    console.log(event, type);
    i18next.changeLanguage(event["value"])
    //console.log("type", type);
    switch (type) {
      case "lang":
        this.setState({ lang: event });
        break;
    }
  };

  handleChange = (event: any) => {
    if (event.target.checked) {
      i18next.changeLanguage("ar");
      this.setState({ lang: { label: "Arabic", value: "ar" } });
    }else{
      i18next.changeLanguage("en");
      this.setState({ lang: { label: 'English', value: "en" } });
    }
    // setState({ ...state, [event.target.name]: event.target.checked });
  };


  render() {
    const { t } = this.props;
    return (
      <header id="header" className="fixed-top header-transparent">
        <div className="container d-flex justify-content-between align-items-center">
          <Link to={`${process.env.PUBLIC_URL}/`}>
            <div className="logo">
              <h1 className="text-light">
                <a href="index.html"><img className="logo" src={`${process.env.PUBLIC_URL}/img/logo.png`}></img><span>Al-Siraj</span> <span style={{ color: "#CC9E63" }}>Computer</span><span>&nbsp;Design</span></a></h1>
            </div>
          </Link>

          <nav className="nav-menu float-right d-none d-lg-block">
            <ul>

              <li className="drop-down active"><NavLink to={`${process.env.PUBLIC_URL}/#Home`}>{t("menu-home")}</NavLink>
                <ul>
                  <li><NavLink to={`${process.env.PUBLIC_URL}/about`}>{t("menu-about")} </NavLink></li>
                  <li> <NavLink to={`${process.env.PUBLIC_URL}/ourvision`}>{t("menu-vision")} </NavLink></li>
                  <li><NavLink activeClassName={"active"} to={`${process.env.PUBLIC_URL}/chairmanspeech`}>{t("menu-chairman")}</NavLink></li>
                </ul>
              </li>

              <li > <NavLink to={`${process.env.PUBLIC_URL}/partners`}>{t("menu-partners")}</NavLink></li>
              <li > <NavLink to={`${process.env.PUBLIC_URL}/contact`}>{t('menu-contact')}</NavLink></li>

              <React.Fragment>
                {
                  this.state.userName != "" ?
                    <React.Fragment>

                      <li > <NavLink to={`${process.env.PUBLIC_URL}/dashboard`}>{t('menu-dashboard')}</NavLink></li>
                      <li><Link to={`#`} onClick={this.ProceedLogout}>{t('menu-logout')}</Link></li>
                    </React.Fragment>
                    :
                    <React.Fragment>
                      <li> <NavLink to={`${process.env.PUBLIC_URL}/login`}>{t('menu-signin')}</NavLink></li>
                    </React.Fragment>
                }
              </React.Fragment>
              <li style={{ width: 100 }}>
                <label htmlFor="langSwitch">English</label>
                <Switch
                  onChange={this.handleChange}
                  checked={this.state.lang.value === "en" ? false : true}
                  name="langSwitch"
                  id="langSwitch"
                />
                <label htmlFor="langSwitch">Arab</label>
                {/* <Select class="form-control language-selector"
                  options={[{ label: 'English', value: "en" }, { label: 'Arabic', value: "ar" }]}
                  onChange={(e: any) =>
                    this.drowpDownChange(e, "lang")
                  }
                  value={this.state.lang}
                  arrowClosed={<span className="arrow-closed" />}
                  arrowOpen={<span className="arrow-open" />}
                  placeholder="Language"
                /> */}
              </li>

            </ul>
          </nav>



        </div>
      </header>
    );
  }
})