import React from "react";
import MaterialTable from "material-table";
import { makeStyles} from "@material-ui/core";
import { isEmpty } from "appredux/common/validationUtils";

const useStyles = makeStyles({
  root: {
    backgroundColor: '#fff',
    padding: 0,
    "& .MuiPaper-root": {
      boxShadow: 'none',
      "& .MuiTableCell-head": {
      },
    },
    '& .action-menu': {
      padding: '0px 5px 0px 5px',
      '& .ml-15': {
        marginLeft: 15
      }
    },
  },

});

interface IProps {
  datasource: any,
  coldefs: any,
  options: any,
  title?: any,
  actions?: any,
  detailpanel?: any,
  isloading?: any,
  onRowClickCallback?:any
}
type Props = IProps;

function DataTable(props: Props) {
  const classes = useStyles();
  const onRowClick = (rowdata:any) => {
    if ( props.onRowClickCallback != null ){
      props.onRowClickCallback(rowdata);
    }
  };
  return (
    <div className={classes.root} >
     
      <MaterialTable 
        title= {!isEmpty(props.title) ? props.title :""}
        localization={{
          toolbar: {
            nRowsSelected: '{0} row(s) selected'
          },
          header: {
            actions: ''
          },
          body: {
            emptyDataSourceMessage: 'No data available!',
          }
        }}
        columns={props.coldefs}
        data={props.datasource}        
        actions={props.actions}
        detailPanel={props.detailpanel}
        onRowClick={((evt: any, selectedRow: any) =>onRowClick(selectedRow))}
        options={props.options}
        isLoading={props.isloading}
      />
      </div>
  );
}

export default DataTable;