import React, { useEffect } from 'react';
import { Route, withRouter } from 'react-router-dom';


const ScrollToTopRoute = withRouter( ( { component: Component, location, path, ...rest }: any ) => {
    
    useEffect(()=>{
        if (path === location.pathname) {
            window.scrollTo(0, 0)
        }
    },[location, path]);

    return <Route {...rest} render={props => (<Component {...props} />)} />;
});

export default ScrollToTopRoute;