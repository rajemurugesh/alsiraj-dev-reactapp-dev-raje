interface Window{
    WebChat: any,
    initOnDomReady: any,
    jqueryUi: any,
    location: any,
    jQuery:any,
    sidebarMenu: any
}