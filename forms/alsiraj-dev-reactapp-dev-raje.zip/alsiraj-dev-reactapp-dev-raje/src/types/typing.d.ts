declare module 'react-step-progress';
declare module 'react-select';
declare module 'react-toastify';
declare module 'react-tabs';
declare module 'react-input-mask';
declare module 'react-facebook-login/dist/facebook-login-render-props';


declare module "redux-react-session" {     
    export interface reducerType{
        authenticated: boolean,
        checked: boolean,
        invalid: boolean,
        user: object
    }

    export function sessionReducer() : reducerType

    export class sessionService {
        static initSessionService(store: any, options: object): any;
        static saveSession(session: any): any;
        static saveUser(data: any): any;
        static loadSession(): any;
        static loadUser(): any;
        static deleteSession(): any;
        static deleteUser(): any;
    }    
}

declare module "simple-update-in";