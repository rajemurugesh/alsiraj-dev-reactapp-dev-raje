export class LoadExternalJs{
    scriptTag(src: string, async: boolean = false) {
        return new Promise((resolve, reject) => {
          let resolved = false,
              errored = false,
              body = document.getElementsByTagName('body')[0],
              tag: any = document.createElement('script');
    
          tag.type = 'text/javascript';
          tag.async = async; // Load in order
    
          const handleLoad = (evt?: any) => {resolved = true;resolve(src);}
          const handleReject = (evt?: any) => {errored = true; reject(src) }

          const handleCallback = tag.onreadystatechange = function() {
            if (resolved) return handleLoad();
            if (errored) return handleReject();
            const state = tag.readyState;
            if (state === 'complete') {
              handleLoad()
            } else if (state === 'error') {
              handleReject()
            }
          }
          
          tag.addEventListener('load', handleLoad)
          tag.addEventListener('error', handleReject);
          tag.src = src;
          body.appendChild(tag);
          return tag;
        });
      }
}