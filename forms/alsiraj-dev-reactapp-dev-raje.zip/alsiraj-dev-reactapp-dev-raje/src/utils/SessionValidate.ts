import MakeApiRequest from "utils/ApiRequest";
import Storage from "./StorageManagement";

export const validateSession = async () => {
    const SessionValues = await Storage.getUserData();
    const validateSessionflag = await MakeApiRequest.post("auth/getnewtoken", JSON.parse(JSON.stringify({
        refreshtoken: SessionValues.RefreshToken,
    }))).then(async (response: any) => {
        const { data } = response;
        if (data != null) {
            if (data.status) {
                if (data["token"] !=null) {
                    if (data.status){
                        const items = {
                            "AccessToken": data.token,
                            "RefreshToken": data.refreshtoken,
                        };
                        await Storage.saveUserSession(items);
                        return true;
                    }else{
                        await Storage.setObject({
                            "AccessToken": data.token,
                            "RefreshToken": data.refreshtoken,
                        });
                        return true;
                    }                    
                }else {
                    return false;
                }
            }            
            else {
                return false;
            }
        }        
        else
            return false;
    })
        .catch((errorresponse: any) => {
            console.log('error' + errorresponse);
            return false;
        });
    return validateSessionflag;
};