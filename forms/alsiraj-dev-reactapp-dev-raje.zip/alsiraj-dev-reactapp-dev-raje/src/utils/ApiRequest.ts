import axios, {AxiosInstance} from 'axios';
import Storage from "./StorageManagement";
import { Error } from 'appredux/model/common';

class Request{
    baseURL: string;
    isRefreshing: boolean;
    failedRequests: Array<any>;
    failedNoInternetRequests: Array<any>;
    client: AxiosInstance;

    constructor(){
        this.baseURL = process.env.REACT_APP_SERVICE_ENDPOINT!;
        this.isRefreshing = false;
        this.failedRequests = [];
        this.failedNoInternetRequests = [];
        this.client = axios.create({
            baseURL: this.baseURL,
            headers: {
                Authorization: '',
                'Access-Control-Allow-Origin': process.env.REACT_APP_URL                
            }
        });
        this.beforeRequest = this.beforeRequest.bind(this);
        this.onRequestSuccess = this.onRequestSuccess.bind(this);
        this.onRequestFailure = this.onRequestFailure.bind(this);
        this.processQueue = this.processQueue.bind(this);
        this.encodeString = this.encodeString.bind(this);
        this.client.interceptors.request.use(this.beforeRequest);
        this.client.interceptors.response.use(this.onRequestSuccess, this.onRequestFailure);   
    }

    async beforeRequest(request:any){
        const sessionData = await Storage.getUserData();
        
        if ( sessionData != null ){
            request.headers.Authorization = `Bearer ${sessionData.AccessToken}`;
        }        
        request.headers.ContentType = "application/json";
        // const netInfo = useNetInfo();
        // if ( !netInfo.isConnected && !netInfo.isInternetReachable){
        //     this.failedNoInternetRequests.push(request);
        // }
        return request;
    }
    onRequestSuccess(response:any){
        return response;
    }
    encodeString(value:any){
        return encodeURIComponent(value);
    }
    async onRequestFailure(err:any){
        const { response } = err; 
        console.log("failure response", err, response);       
        if ( typeof response != 'undefined' && response.status == 401 && err && err.config && !err.config.__isRetryRequest ){
            if ( this.isRefreshing ){
                try{
                    const token = await new Promise((resolve, reject)=>{
                        this.failedRequests.push({resolve, reject});
                    });
                    err.config.headers.Authorization = `Bearer ${token}`;
                    return this.client(err.config);
                }catch(e){
                    return e;
                }
            }
            this.isRefreshing = true;
            err.config.__isRetryRequest = true;
            return new Promise(async (resolve, reject)=>{
                const SessionValues = await Storage.getUserData();  
                if ( SessionValues != null && typeof SessionValues.RefreshToken != "undefined" ){
                    axios.post(`${this.baseURL}/Token/Refresh`,null,{
                        params:{
                            token: this.encodeString(SessionValues.RefreshToken)
                        },
                        headers:{
                            Authorization: `Bearer ${SessionValues.AccessToken}`
                        }
                    })
                    .then(async (response)=>{
                        const {data} = response;                        
                        if ( typeof data.Result["access_token"] != "undefined" ){
                            await Storage.setObject({
                                "AccessToken" : data.Result.access_token,
                                "RefreshToken" : data.Result.refresh_token
                            });
                            axios.defaults.headers["Authorization"] = `Bearer ${data.Result.access_token}`;
                            err.config.headers["Authorization"] = `Bearer ${data.Result.access_token}`;
                            this.processQueue(null, data.Result.access_token);
                            resolve(this.client(err.config));
                        }else{
                            let errorMsg = {} as Error;
                            errorMsg.IsError = true;
                            errorMsg.ExceptionMessage = "AccessToken is missing";
                            this.processQueue(errorMsg, null);
                            reject(errorMsg);
                        }                        
                    })
                    .catch((err)=>{
                        this.processQueue(err, null);
                        reject(err);
                    })
                    .then(()=>{
                        this.isRefreshing = false;
                    });
                }else{
                    let errorMsg = {} as Error;
                    errorMsg.IsError = true;
                    errorMsg.ExceptionMessage = "RefreshToken is missing";
                    this.processQueue(errorMsg, null);
                    reject(errorMsg.ExceptionMessage);
                }                
            });
        }
        else if (typeof response == "undefined" ){
            //err.config.__isRetryRequest = true;
            return Promise.reject(err);
        }
        else{
            return Promise.reject(err);
        } 
    }
    processQueue(error: any, token=null){
        this.failedRequests.forEach((prom)=>{
            if ( error ){
                prom.reject(error);
            } else {
                prom.resolve(token);
            }
        });
        this.failedRequests = [];
    }
    processFailedRequests(){
        this.failedNoInternetRequests.forEach((request)=>{
           this.client(request);
        });
        this.failedNoInternetRequests = [];
    }
}

const request = new Request();

export default request.client;