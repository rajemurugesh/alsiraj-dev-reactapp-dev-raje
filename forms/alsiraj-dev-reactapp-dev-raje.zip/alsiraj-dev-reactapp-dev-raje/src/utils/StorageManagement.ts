import { sessionService } from "redux-react-session";
import { Storage } from "appredux/model/common";

class StorageManagement
{
    static saveSession(token: string){
        return new Promise(
            (resolve, reject) => sessionService
                                        .saveSession(token)
                                        .then(resolve(true))
                                        .catch((err: any)=>resolve(false))
        );
    }

    static saveData(value: object){
        return new Promise(
            (resolve, reject) => sessionService
                                        .saveUser(value)
                                        .then(resolve(true))
                                        .catch((err: any)=>resolve(false))
        );
    }

    static async setItem(key: string, value:string){
        var currentData = await this.getUserData();
        if ( currentData != null ){
            await this.saveData({...currentData,...{[key]:value}});    
        }else{
            await this.saveData({[key]:value});
        }
        
    }

    static async setObject(value:object){
        var currentData = await this.getUserData();
        if ( currentData != null ){
            await this.saveData({...currentData,...value});    
        }else{
            await this.saveData(value);
        }
        
    }

    static getSession() : Promise<string>{
        return new Promise(
            (resolve, reject)=>sessionService
                                .loadSession()
                                .then((sessionData: string) => {
                                    resolve(sessionData);
                                }).catch((err:any)=>{
                                    resolve(null!);
                                })
        );        
    }

    static getUserData() : Promise<Storage>{
        return new Promise(
            (resolve, reject)=>sessionService
                                .loadUser()
                                .then((userData: Storage) => {
                                    resolve(userData);
                                }).catch((err:any)=>{
                                    resolve(null!);
                                })
        );        
    }

    static getAccessToken() : Promise<string>{
        return new Promise(
            (resolve, reject)=> sessionService
                                    .loadUser()
                                    .then((userData: Storage) => {
                                        //console.log("dddd", userData);
                                        resolve(userData.AccessToken);
                                    }).catch((err:any)=>{
                                        //console.log("error", err);
                                        resolve(null!);
                                    })
        );     
    }

    static getRefreshToken() : Promise<string>{
        return new Promise(
            (resolve, reject) => sessionService
                                    .loadUser()
                                    .then((userData: Storage) => {
                                        resolve(userData.RefreshToken);
                                    }).catch((err:any)=>{
                                        resolve(null!);
                                    })
        );    
    }

    static async saveUserSession(value: Storage){
        var saveStatus = await this.saveSession(value.AccessToken);  
        if ( saveStatus ){
            return await this.setObject(value);
        }
        return saveStatus;        
    }

    static deleteSessionData() : Promise<boolean>{
        return new Promise(
            (resolve, reject) => sessionService
                                    .deleteSession()
                                    .then((userData: any) => {
                                        resolve(true);
                                    }).catch((err:any)=>{
                                        resolve(false);
                                    })
        );    
    }
    
    static deleteUserData() : Promise<boolean>{
        return new Promise(
            (resolve, reject) => sessionService
                                    .deleteUser()
                                    .then((userData: any) => {
                                        resolve(true);
                                    }).catch((err:any)=>{
                                        resolve(false);
                                    })
        );    
    }

    static async deleteUserSession(){
        var deleteSession = await this.deleteSessionData();  
        if ( deleteSession ){
            return await this.deleteUserData();
        }
        return deleteSession;
    }
    
}

export default StorageManagement;