import { MsalAuthProvider, LoginType } from 'react-aad-msal';
import { Config } from 'Config';
import Axios, {AxiosInstance} from 'axios';

export const authProvider = new MsalAuthProvider(
    {
        auth: {            
            authority: "https://login.microsoftonline.com/"+Config.TenantId, //Directory (tenant) ID Overview blade of App Registration
            clientId: "" + Config.LoginAppClientId, //Application (client) ID            
            postLogoutRedirectUri: Config.AppUrl,
            redirectUri: Config.AppUrl            
        },
        cache: {
            cacheLocation: 'sessionStorage',
            storeAuthStateInCookie: true,            
        }
    },

    {
        scopes: ['https://graph.microsoft.com/.default']
    },

    {
        loginType: LoginType.Popup
    }
);

export const registerProvider = new MsalAuthProvider(
    {
        auth: {
            authority: "https://login.microsoftonline.com/common", // To access all microsoft account            
            clientId: "" + Config.RegisterAppClientId, //Application (client) ID
            postLogoutRedirectUri: Config.AppUrl,
            redirectUri: Config.AppUrl
        },
        cache:{            
            //cacheLocation: 'sessionStorage',
            storeAuthStateInCookie: false
        }        
    },
    {
        scopes: ['https://graph.microsoft.com/.default'],
        forceRefresh: true
    },
    {
        loginType: LoginType.Popup
    }
);

export const authFetch = async () : Promise<AxiosInstance> => {
    const token = await authProvider.getIdToken();

    const instance = Axios.create({
        baseURL: process.env.REACT_APP_SERVICE_ENDPOINT+'api',
        timeout: 60000,
        headers: {
            Authorization: 'Bearer ' + token.idToken.rawIdToken,
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': Config.AppUrl,
            'Access-Control-Allow-Credentials': true
        },
        withCredentials:true
      });

    return instance;
};
