import { Error, UserRole } from 'appredux/model/common';
import moment from 'moment';
import StorageManagement from 'utils/StorageManagement';
import { isEmpty } from './validationUtils';

export function ParseErrorResponse(error: any) {
    if (typeof error["response"] != "undefined") {
        const errorOutput = error.response;
        if (typeof errorOutput.data["ResponseException"] != "undefined") {
            const error = errorOutput.data.ResponseException as Error;
            return error;
        } else {
            let errorMsg = {} as Error;
            errorMsg.IsError = true;
            errorMsg.ExceptionMessage = errorOutput.data.toString();
            return errorMsg;
        }
    } else {
        let errorMsg = {} as Error;
        errorMsg.IsError = true;
        errorMsg.ExceptionMessage = error.toString();
        return errorMsg;
    }
}
export function IsoDatetoStringformat(input: string) {
    if (!isEmpty(input)) {
        let mm = '';
        let dd = '';
        let date = new Date(input);
        let year = date.getFullYear();
        const data = date.getMonth() + 1;
        let month = parseInt(data.toString(), 10);
        let dt = date.getDate();
        if (dt < 10) {
            dd = '0' + dt.toString();
        }
        else
            dd = dt.toString();
        if (month < 10) {

            mm = '0' + month.toString();
        }
        else
            mm = month.toString();
        return year + '-' + mm + '-' + dt;
    }
    else
        return '';
}


interface  UserRolePermission{
    TrailStatus:boolean,
    SubscriptionStatus:boolean,
    UserRole:string,
    TrialDaysCount:number
}


export function getUserRoleBasePermission(input: any) {
    let Trailobj=  input.filter((x:any) => x.Role == UserRole.Trail  || UserRole.Internal || UserRole.Subscribe  || UserRole.Trader);
    let userRolePermission={} as UserRolePermission;
    if(Trailobj.length > 0){
        userRolePermission.TrailStatus=!isEmpty(Trailobj[0]?.TrialStatus) ? Trailobj[0]?.TrialStatus:false;
        userRolePermission.SubscriptionStatus=!isEmpty(Trailobj[0]?.SubscriptionStatus) ? Trailobj[0]?.SubscriptionStatus:false;
        userRolePermission.UserRole=!isEmpty(Trailobj[0]?.Role) ? Trailobj[0]?.Role:UserRole.Trail;
        userRolePermission.TrialDaysCount=!isEmpty(Trailobj[0]?.TrialDaysCount) ? Trailobj[0]?.TrialDaysCount:0;
        return userRolePermission;
    }
    else{
        return  userRolePermission;
    }
}

// export async function checkForRoleExists(role: any) {
//     let userData = await StorageManagement.getUserData();    
//     if ( !isEmpty(userData?.Roles) ) {
//         let roles = JSON.parse(userData?.Roles!) as Array<string>;        
//         let roleFound = roles.indexOf(role);
//         return roleFound !== -1 ? true : false;
//     }
//     return false;
// }

export function formatDateTimeOffset(date: any, format?: any){
    return moment(date).format(typeof format === "undefined" ? "MM/DD/YYY HH:mm Z" : format);
}



