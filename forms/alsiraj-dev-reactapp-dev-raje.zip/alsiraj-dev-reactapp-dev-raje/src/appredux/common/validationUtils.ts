export const isEmpty = (value:any) => value === undefined || value === null || value === '';
export const trim = (value:string) => value.replace(/^\s+/,'').replace(/\s+$/,'');
export const isAlphaSpace = (input:string) => /^[a-zA-Z\s]*$/gi.test(input);

export function email(value:string) {
  // eslint-disable-next-line no-useless-escape
  if ( !isEmpty(value) && /^[a-zA-Z0-9\.]+@[a-zA-Z\.]+\.[a-zA-Z]{2,5}$/gi.test(value) ){ 
    return true;
  }
  else
    return false;
}

export function emailUserNameLengthCheck(value:string) {
  // eslint-disable-next-line no-useless-escape
  if ( !isEmpty(value) && /^[a-zA-Z0-9\.]{1,30}@/gi.test(value) ){ 
    return true;
  }
  else
    return false;
}

export function required(value:any, checkValue:any="") {
  if (isEmpty(value==null ? "":trim(value)) || value === checkValue) {
    return true;
  }
  else
    return false;
}

export function minLength(min:number,value:any) {
  if (!isEmpty(value) && value.length < min) {
    return true;
  }
  else
    return false;
}

export function maxLength(max:number, value:any) {
  if (!isEmpty(value) && value.length > max) {
    return true
  }
  else
    return false;
}

export function integer(value:any) {
  if (!Number.isInteger(Number(value))) {
    return true;
  }
  else
    return false;
}

export function expirydateconversiontouniversal(expiry:any){
  if ( !isEmpty(expiry) ){
    var eadate = expiry.split("/");
    var nedate = (eadate.length > 0 ? eadate[1] : "")+"-"+eadate[0];
    return nedate;
  }
  return null;  
}

export function expiredatevalidate(input:any) {
  var expiryDate = expirydateconversiontouniversal(input);
  if ( expiryDate != null ){
    const today = new Date(); 
    const data=today.getMonth() + 1; 
    let today_mm = parseInt(data.toString(),10); 
    const today_yyyy= today.getFullYear(); 
      if(today_mm < 10) { 
          today_mm = parseInt('0' + today_mm.toString(),10);
      } 
      var yy = parseInt(expiryDate.substring(0, 4),10);
      var mm = parseInt(expiryDate.substring(6),10); 
      if (yy > today_yyyy || (yy == today_yyyy && mm >= today_mm)) {
        return true;
    }
  }
  return false;  
}