import { createStore, applyMiddleware, combineReducers, compose, Action } from 'redux';
import thunk, { ThunkAction } from 'redux-thunk';
import {validateSession} from "utils/SessionValidate";
import { sessionService } from 'redux-react-session';
import * as AllReducers from 'appredux/modules/index';

const storeEnhancers = (window as any).__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

const middlewares = [thunk];
if (process.env.NODE_ENV === `development`) {
  const {logger} =  require('redux-logger');
  //const loggerMiddleware = createLogger(); // initialize logger
  middlewares.push(logger);
}

//const createStoreWithMiddleware = applyMiddleware(loggerMiddleware)(createStore); // apply logger to redux

const appReducers = combineReducers(AllReducers);

export type RootState =  ReturnType<typeof appReducers>;

export type AppThunk<ReturnType = void> = ThunkAction<ReturnType, RootState, null, Action<string>>;

//const configureStore = (initialState) => createStoreWithMiddleware(reducer, initialState);

const configureStore = createStore(
  appReducers,
  storeEnhancers(applyMiddleware(...middlewares))
);

export type AppDispatch = typeof configureStore.dispatch;

//Init session
// sessionService.initSessionService(configureStore, {driver:"COOKIES", expires: ""});
const options = { refreshOnCheckAuth: true, redirectPath: '/', driver: 'LOCALSTORAGE', validateSession };
  sessionService.initSessionService(configureStore, options)
    .then(() => console.log('Redux React Session is ready and a session was refreshed from your storage'))
    .catch(() => console.log('Redux React Session is ready and there is no session in your storage'));

export default configureStore;