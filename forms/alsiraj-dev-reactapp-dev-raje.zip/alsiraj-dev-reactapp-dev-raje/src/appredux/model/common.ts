export interface Error {
  IsError: boolean,
  ExceptionMessage: string,
  Details: string,
  ReferenceErrorCode: string,
  ReferenceDocumentLink: string,
  ValidationErrors: string
}

export interface Storage{
  AccessToken: string,
  RefreshToken: string,
  UserName?: string,
  AppUser?: string,
  UserId?: string,

  



}
export interface Competition{
  Title: string,
  Date: string,
  Purpose?: string,
  DocumentLink?: string,
  CompetitionId?:string,
  UserId?:string,
  UserName?:string,
  Status?:string
}

export enum UserType{
  AppUser = "app",
  SocialUser = "social"
}

export enum SocialAccountType{    
  Facebook = "facebook",
  Google = "google",
  Microsoft = "microsoft"
}

export enum UserRole{
  Trail = "Trail",
  Internal = "Internal",
  Subscribe='Subscribe',
  Trader='Trader'
}

export enum PlanType{
  Basic = "BASIC PLAN",
  Community = "COMMUNITY PLAN",
  Premium='PREMIUM PLAN'
}

export interface RegisterUser {
  EmailId: string,
  Password: string,
  UserName: string,
  YourName?: string,
  FirstName: string,
  LastName: string,
  PhoneNumber:string,
  AppUser?:string,
  UserType?:string,
  DocumentUrl?:string
}

export interface Payment {
  plan_id: any,
  quantity: string,   
  firstname: string,
  lastname: string,
  email:string,
  address_line_1: string,
  address_line_2: string,
  admin_area_2: string,
  admin_area_1: string,
  postal_code: string,
  country_code: string,
  number:string,
  expiry:string,
  security_code: string,
  IsCradPay:boolean,
  currency?:any | null,
  stateId?:string | null,
  countryId?:string | null,
  subscriptionPlanId?:string | null,
  products?:Array<any> | null,
  subscriptionId?:string,
  subscriptionStatus?:string



}

export interface Subscription {
  plan_id: any,
  subscriptionPlanId?:string | null,
  products?:Array<any> | null,
  subscriptionId?:string,
  subscriptionStatus?:string,
  currency?:any | null,
}


export interface SocialInput{
  token: string
}
export interface FormState {
  loading: boolean | null,
  success: any | null,
  error: Error | null,
  isSubmitBtnClicked?: boolean | null,
  isFormValid?: boolean | null
}



export interface CreateAccount {
  FirstName: string,
  LastName: string,
  UserName: string,
  EmailId:string,
  PhoneNumber: string,
}
