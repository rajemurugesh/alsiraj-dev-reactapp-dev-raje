import MakeApiRequest from "utils/ApiRequest";
import { AppThunk } from "appredux/configureStore";
import { Error, FormState, RegisterUser } from "appredux/model/common";
import { ParseErrorResponse } from "appredux/common/utils";
import { required, maxLength, email, emailUserNameLengthCheck, minLength } from "appredux/common/validationUtils";

//Types
export interface User {
  EmailId: string,
  Password?: any
}


export interface Skill {
  Skills: string,
  Exp?: any,
  UserId?:any
}


export interface CompetitionMaster {
  competitionname: string,
  startdate: Date,
  enddate: Date,
  status:string,
  description: string,
  type: string,
}




export interface LoginState extends FormState {
  validationErrors: any | null,
  skillloading: any,
  skillerror: Error | null,
  skillsuccess: any,
  skillisFormValid:  boolean | null
  skillisSubmitBtnClicked:  boolean | null
  validationSkillsErrors: any | null,
  skilllistloading: any,
  skilllisterror: Error | null,
  skilllistsuccess: any,
  data: null,

}

// Actions
export const LOGIN_PROGRESS = 'alsiraj/login/PROGRESS';
export const LOGIN_INPUT_ENTRY = 'alsiraj/login/INPUT_ENTRY';
export const LOGIN_VALIDATE_FORM = 'alsiraj/login/VALIDATE_FORM';
export const LOGIN_FORM_RESET = 'alsiraj/login/FORM_RESET';
export const LOGIN_SUBMIT = 'alsiraj/login/SUBMIT';
export const LOGIN_SUBMIT_CLICKED = 'alsiraj/login/SUBMIT/CLICK';
export const LOGIN_SUCESS = 'alsiraj/login/SUCCESS';
export const LOGIN_FAILS = 'alsiraj/login/FAILS';


export const SKILL_SUBMIT = 'alsiraj/SKILL/SUBMIT';
export const SKILL_SUBMIT_CLICKED = 'alsiraj/SKILL/SUBMIT/CLICK';
export const SKILL_SUCESS = 'alsiraj/SKILL/SUCCESS';
export const SKILL_FAILS = 'alsiraj/SKILL/FAILS';
export const SKILL_PROGRESS = 'alsiraj/SKILL/PROGRESS';
export const SKILL_VALIDATE_FORM = 'alsiraj/SKILL/VALIDATE_FORM';

export const GET_SKILLS_PROGRESS = "alsiraj/SKILLS/PROGRESS";
export const GET_SKILLS_SUCESS = "alsiraj/SKILLS/SUCCESS";
export const GET_SKILLS_FAILS = "alsiraj/SKILLS/FAILS";


export const Competition_SUBMIT = 'alsiraj/Competition/SUBMIT';
export const Competition_SUBMIT_CLICKED = 'alsiraj/Competition/SUBMIT/CLICK';
export const Competition_SUCESS = 'alsiraj/Competition/SUCCESS';
export const Competition_FAILS = 'alsiraj/Competition/FAILS';
export const Competition_PROGRESS = 'alsiraj/Competition/PROGRESS';
export const Competition_VALIDATE_FORM = 'alsiraj/Competition/VALIDATE_FORM';

export const GET_Competition_PROGRESS = "alsiraj/Competition/PROGRESS";
export const GET_Competition_SUCESS = "alsiraj/Competition/SUCCESS";
export const GET_Competition_FAILS = "alsiraj/Competition/FAILS";




interface LoginSubmitAction {
  type: typeof LOGIN_SUBMIT,
  payload: User
}

interface LoginSubmitClickedAction {
  type: typeof LOGIN_SUBMIT_CLICKED,
  payload:boolean
}

interface LoginProgressAction {
  type: typeof LOGIN_PROGRESS,
  payload: boolean
}

interface LoginSuccessAction {
  type: typeof LOGIN_SUCESS,
  payload: boolean
}

interface LoginFailAction {
  type: typeof LOGIN_FAILS,
  payload: Error
}

interface LoginValidateFormAction {
  type: typeof LOGIN_VALIDATE_FORM,
  payload: User,
  isValid: boolean
}

interface LoginFormResetAction {
  type: typeof LOGIN_FORM_RESET
}



interface SkillSubmitAction {
  type: typeof SKILL_SUBMIT,
  payload: Skill
}

interface SkillSubmitClickedAction {
  type: typeof SKILL_SUBMIT_CLICKED,
  payload:boolean
}

interface SkillProgressAction {
  type: typeof SKILL_PROGRESS,
  payload: boolean
}

interface SkillSuccessAction {
  type: typeof SKILL_SUCESS,
  payload: boolean
}

interface SkillFailAction {
  type: typeof SKILL_FAILS,
  payload: Error
}

interface SkillValidateFormAction {
  type: typeof  SKILL_VALIDATE_FORM,
  payload: Skill,
  isValid: boolean
}


interface SkillsProgressAction {
  type: typeof GET_SKILLS_PROGRESS;
  payload: boolean;
}

interface SkillsSuccessAction {
  type: typeof GET_SKILLS_SUCESS;
  payload: any;
}

interface SkillsFailAction {
  type: typeof GET_SKILLS_FAILS;
  payload: Error;
}


export type LoginActionTypes = LoginSubmitAction | LoginSuccessAction | LoginFailAction | LoginFormResetAction | 
  LoginProgressAction | LoginValidateFormAction | LoginSubmitClickedAction | SkillSubmitAction | SkillSubmitClickedAction | SkillProgressAction  | SkillSuccessAction 
  | SkillValidateFormAction | SkillFailAction | SkillsProgressAction | SkillsSuccessAction| SkillsFailAction;

const initialState: LoginState = {
  loading: null,
  error: null,
  success: null,
  validationErrors: null,
  isFormValid: null,
  isSubmitBtnClicked: null,
  skillloading: null,
  skillerror: null,
  skillsuccess: null,
  skillisFormValid: null,
  skillisSubmitBtnClicked: null,
  validationSkillsErrors:null,
  skilllistloading: null,
  skilllisterror: null,
  skilllistsuccess: null,
  data: null,
 
};

// Reducer
export default function reducer(state = initialState, action: LoginActionTypes): LoginState {
  switch (action.type) {
    case LOGIN_PROGRESS:
      // Perform action
      return {
        ...state,
        loading: action.payload
      };
    case LOGIN_SUBMIT_CLICKED:
      return {
        ...state,
        isSubmitBtnClicked:action.payload,
      };
    case LOGIN_VALIDATE_FORM:
      // Perform action
      return {
        ...state,
        validationErrors: action.payload,
        isFormValid: action.isValid
      };
    case LOGIN_FORM_RESET:
      // Perform action
      return {
        ...state,
        validationErrors: null,
        isFormValid: null,
        isSubmitBtnClicked: null,
        loading: null,
        success: null,
        error: null
      };
    case LOGIN_FAILS:
      return {
        ...state,
        success: false,
        error: action.payload
      }
    case LOGIN_SUCESS:
      return {
        ...state,
        success: action.payload,
        error: null
      }
      case SKILL_PROGRESS:
      // Perform action
      return {
        ...state,
        skillloading: action.payload
      };
    case SKILL_SUBMIT_CLICKED:
      return {
        ...state,
        skillisSubmitBtnClicked:action.payload,
      };
    case SKILL_VALIDATE_FORM:
      // Perform action
      return {
        ...state,
        validationSkillsErrors: action.payload,
        skillisFormValid: action.isValid
      };
  
    case SKILL_FAILS:
      return {
        ...state,
        skillsuccess: false,
        skillerror: action.payload
      }
    case SKILL_SUCESS:
      return {
        ...state,
        skillsuccess: action.payload,
        skillerror: null
      }
      case GET_SKILLS_PROGRESS:
      // Perform action
      return {
        ...state,
        skilllistloading: action.payload,
      };
    case GET_SKILLS_FAILS:
      return {
        ...state,
        skilllistsuccess: false,
        skilllisterror: action.payload,
      };
    case GET_SKILLS_SUCESS:
      return {
        ...state,
        skilllistsuccess: true,
        data: action.payload,
        skilllisterror: null,
      };   
      
  
    default: return state;
  }
}

// Action Creators
export const ResetForm = (): AppThunk => async dispatch => {
  dispatch({ type: LOGIN_FORM_RESET });
}

export const SubmitloginBtnClicked = (params:boolean): AppThunk => async dispatch => {
  dispatch({ type: LOGIN_SUBMIT_CLICKED,payload:params });
}

export const SubmitLogin = (params: User): AppThunk => async dispatch => {
  dispatch({ type: LOGIN_PROGRESS, payload: true });
  MakeApiRequest.post('auth/signin', params)
    .then(response => {
      dispatch({ type: LOGIN_PROGRESS, payload: false });
      dispatch({ type: LOGIN_SUCESS, payload: response.data });
    })
    .catch(errorresponse => {
      dispatch({ type: LOGIN_PROGRESS, payload: false });
      dispatch({ type: LOGIN_FAILS, payload: ParseErrorResponse(errorresponse) });
    });
}

export const ValidateForm = (params: User): AppThunk => async dispatch => {
  let userValidationError = {} as User;
  let isValid: boolean = true;
  var upperCaseExpression = /[A-Z]/;
  var lowerCaseExpression = /[a-z]/;
  var NumberExpression = /[0-9]/;
  var specialCaseExpression = /(?=.*\W)/;

  if (required(params.Password)) {
    userValidationError.Password = "Please enter Password";
    isValid = false;
  }
  // else if (!upperCaseExpression.test(params.Password)) {
  //   userValidationError.Password = 'Password should contain at least one upper case letter.';
  //   isValid = false;
  // }
  // else if (!lowerCaseExpression.test(params.Password)) {
  //   userValidationError.Password = 'Password should contain at least one lower case letter.';
  //   isValid = false;
  // }
  // else if (!NumberExpression.test(params.Password)) {
  //   userValidationError.Password = 'Password should contain at least one numeric value.';
  //   isValid = false;
  // }
  // else if (!specialCaseExpression.test(params.Password)) {
  //   userValidationError.Password = 'Password should contain at least special case character.';
  //   isValid = false;
  // }
  else if(minLength(8,params.Password)) {
    userValidationError.Password = "Password should be 8 characters.";
    isValid = false;
  }
  if (required(params.EmailId)) {
    userValidationError.EmailId = "Please enter Email address";
    isValid = false;
  } else if (!email(params.EmailId)) {
    userValidationError.EmailId = "Please enter a Valid Email address";
    isValid = false;
  } else if (!emailUserNameLengthCheck(params.EmailId)) {
    userValidationError.EmailId = "Email address UserName should contain between 1 to 30 characters";
    isValid = false;
  } else if (maxLength(50, params.EmailId)) {
    userValidationError.EmailId = "Email address must be maximum of 50 characters long";
    isValid = false;
  }

  dispatch({ type: LOGIN_VALIDATE_FORM, payload: userValidationError, isValid: isValid });
}



export const SubmitSkillBtnClicked = (params:boolean): AppThunk => async dispatch => {
  dispatch({ type: SKILL_SUBMIT_CLICKED,payload:params });
}

export const SubmitSkill = (params: Skill): AppThunk => async dispatch => {
  dispatch({ type: SKILL_PROGRESS, payload: true });
  MakeApiRequest.post('masters/any/skills/add', params)
    .then(response => {
      dispatch({ type: SKILL_PROGRESS, payload: false });
      dispatch({ type: SKILL_SUCESS, payload: response.data });
    })
    .catch(errorresponse => {
      dispatch({ type: SKILL_PROGRESS, payload: false });
      dispatch({ type: SKILL_FAILS, payload: ParseErrorResponse(errorresponse) });
    });
}

export const SubmitCompetiton = (params: CompetitionMaster): AppThunk => async dispatch => {
  dispatch({ type: SKILL_PROGRESS, payload: true });
  MakeApiRequest.post('masters/any/competition/add', params)
    .then(response => {
      dispatch({ type: SKILL_PROGRESS, payload: false });
      dispatch({ type: SKILL_SUCESS, payload: response.data });
    })
    .catch(errorresponse => {
      dispatch({ type: SKILL_PROGRESS, payload: false });
      dispatch({ type: SKILL_FAILS, payload: ParseErrorResponse(errorresponse) });
    });
}

export const ValidateSkillForm = (params: Skill): AppThunk => async dispatch => {
  let userValidationError = {} as Skill;
  let isValid: boolean = true;
  if (required(params.Skills)) {
    userValidationError.Skills = "Please enter Skills";
    isValid = false;
  }
  if (required(params.Exp)) {
    userValidationError.Exp = "Please enter Experience";
    isValid = false;
  } 

  dispatch({ type: SKILL_VALIDATE_FORM, payload: userValidationError, isValid: isValid });
}




export const GetSkillList = (params:any): AppThunk => async (dispatch) => {
  dispatch({ type: GET_SKILLS_PROGRESS, payload: true });  
  MakeApiRequest.post("masters/any/skills/list")
    .then((response) => {
      dispatch({ type: GET_SKILLS_PROGRESS, payload: false });
      let result=response?.data?.data?.filter((x:any) => x?.UserId === params );
      for (let i = 0; i < result?.length; i++) {
        result[i]["sno"] = i + 1;
      }
      dispatch({ type: GET_SKILLS_SUCESS, payload:result });
    })
    .catch((errorresponse) => {
      dispatch({ type: GET_SKILLS_PROGRESS, payload: false });
      dispatch({
        type: GET_SKILLS_FAILS,
        payload: ParseErrorResponse(errorresponse),
      });
    });
};












