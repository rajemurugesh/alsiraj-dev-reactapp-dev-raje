import { combineReducers } from "redux";
import Login from './Login';
import SignUp from './SignUp';
import ForgotPassword from './ForgotPassword';
import ResetPassword from './ResetPassword';
import CreateAccount from './CreateAccount';
import Competition from './Competition';









export default combineReducers({
    Login,
    SignUp,
    ForgotPassword,
    ResetPassword,
    CreateAccount,
    Competition

});