import MakeApiRequest from "utils/ApiRequest";
import { AppThunk } from "appredux/configureStore";
import { required, isAlphaSpace, maxLength, email, emailUserNameLengthCheck, minLength } from "appredux/common/validationUtils";
import { Error, FormState, RegisterUser } from 'appredux/model/common';
import { ParseErrorResponse } from "appredux/common/utils";
//Types
export interface RegisterState extends FormState {
  validationErrors: RegisterUser | null,
  url:any | null,
  fileSuccess:any,
  fileError:any
}

// Actions
export const REGISTER_PROGRESS = 'alsiraj/register/PROGRESS';
export const REGISTER_INPUT_ENTRY = 'alsiraj/register/INPUT_ENTRY';
export const REGISTER_VALIDATE_FORM = 'alsiraj/register/VALIDATE_FORM';
export const REGISTER_FORM_RESET = 'alsiraj/register/FORM_RESET';
export const REGISTER_SUBMIT = 'alsiraj/register/SUBMIT';
export const REGISTER_SUBMIT_CLICKED = 'alsiraj/register/SUBMIT/CLICK';
export const REGISTER_SUCESS = 'alsiraj/register/SUCCESS';
export const REGISTER_FAILS = 'alsiraj/register/FAILS';


export const REGISTER_FILE_SUCESS = 'alsiraj/fileupload/SUCCESS';
export const REGISTER_FILE_FAILS = 'alsiraj/fileupload/FAILS';

interface RegisterSubmitAction{
  type: typeof REGISTER_SUBMIT,
  payload: RegisterUser 
}

interface RegisterSubmitClickedAction{
  type: typeof REGISTER_SUBMIT_CLICKED,
  payload: boolean
}

interface RegisterProgressAction{
  type: typeof REGISTER_PROGRESS,
  payload: boolean
}

interface RegisterSuccessAction{
  type: typeof REGISTER_SUCESS,
  payload: boolean
}

interface RegisterFailAction{
  type: typeof REGISTER_FAILS,
  payload: Error
}

interface RegisterValidateFormAction{
  type: typeof REGISTER_VALIDATE_FORM,
  payload: RegisterUser,
  isValid: boolean
}

interface RegisterFormResetAction{
  type: typeof REGISTER_FORM_RESET
}

interface RegisterFileAction{
  type: typeof REGISTER_FILE_SUCESS,
  payload: any
}

interface RegisterFileFailAction{
  type: typeof REGISTER_FILE_FAILS,
  payload: Error
}

export type RegisterActionTypes = RegisterSubmitAction | RegisterSuccessAction | RegisterFailAction | RegisterFormResetAction |
                                  RegisterProgressAction | RegisterValidateFormAction | RegisterSubmitClickedAction | RegisterFileAction | RegisterFileFailAction ;

const initialState: RegisterState = {
  loading: null,
  error: null,
  success: null,
  validationErrors: null,
  isFormValid: null,
  isSubmitBtnClicked: null,
  url:null,
  fileSuccess:null,
  fileError:null
};

// Reducer
export default function reducer(state = initialState, action: RegisterActionTypes) : RegisterState {
  switch (action.type) {
    case REGISTER_PROGRESS:
      // Perform action
      return {
        ...state,
        loading: action.payload
      };    
    case REGISTER_SUBMIT_CLICKED:
      return {
        ...state, 
        isSubmitBtnClicked:action.payload,
      };
    case REGISTER_VALIDATE_FORM:
      // Perform action
      return {
        ...state,
        validationErrors: action.payload,
        isFormValid: action.isValid
      };
    case REGISTER_FORM_RESET:
      // Perform action
      return {
        ...state,
        validationErrors: null,
        isFormValid: null,
        isSubmitBtnClicked: null,
        loading: null,
        success: null,
        error: null
      };
    case REGISTER_FAILS:
      return {
        ...state,
        success: false,
        error: action.payload
      }
    case REGISTER_SUCESS:
      return {
        ...state,
        success: action.payload,
        error: null
      }
      case REGISTER_FAILS:
        return {
          ...state,
          success: false,
          error: action.payload
        }
      case REGISTER_FILE_SUCESS:
        return {
          ...state,
          fileSuccess:true,
          url: action.payload,
        }
        case REGISTER_FILE_FAILS:
          return {
            ...state,
            fileSuccess:false,
            fileError: action.payload
          }
    default: return state;
  }
}

// Action Creators
export const RegUserResetForm = () : AppThunk => async dispatch => {
  dispatch({type: REGISTER_FORM_RESET});
}

export const RegUserSubmitBtnClicked = (params:boolean) : AppThunk => async dispatch => {
  dispatch({type: REGISTER_SUBMIT_CLICKED,payload:params});
}

export const SubmitRegisteration = ( params: RegisterUser ) : AppThunk => async dispatch => {
  dispatch({type: REGISTER_PROGRESS, payload: true});
  let formattedUserParams: RegisterUser = JSON.parse(JSON.stringify(params));
  MakeApiRequest.post("masters/any/users/add", formattedUserParams)    
    .then((response: { data: any; })=>{    
      //console.log("success",response.data);
      dispatch({type: REGISTER_PROGRESS, payload: false});
      dispatch({type: REGISTER_SUCESS, payload: response.data});
    })
    .catch((errorresponse: any)=>{    
      dispatch({type: REGISTER_PROGRESS, payload: false});
      dispatch({ type: REGISTER_FAILS, payload: ParseErrorResponse(errorresponse) });
    });  
}

export const RegUserValidateForm = (params: RegisterUser) : AppThunk => async dispatch =>{
  let userValidationError = {} as RegisterUser;
  let isValid:boolean = true;
  var upperCaseExpression = /[A-Z]/;
  var lowerCaseExpression = /[a-z]/;
  var NumberExpression = /[0-9]/;
  var specialCaseExpression = /(?=.*\W)/;
  if ( required(params.UserName) ){    
    userValidationError.UserName = "Please enter User Name";
    isValid = false;
    }
  //else if ( !isAlphaSpace(params.UserName) ){
  //   userValidationError.UserName = "Your Name should contain only Alphabets";
  //   isValid = false;
  // }
  else if ( maxLength(50, params.UserName) ){
    userValidationError.UserName = "Your Name must be maximum of 50 characters long";
    isValid = false;
  }

  if ( required(params.FirstName) ){    
    userValidationError.FirstName = "Please enter First Name";
    isValid = false;
  }else if ( !isAlphaSpace(params.FirstName) ){
    userValidationError.FirstName = "First Name should contain only Alphabets";
    isValid = false;
  }else if ( maxLength(50, params.FirstName) ){
    userValidationError.FirstName = "First Name must be maximum of 50 characters long";
    isValid = false;
  }

  if ( required(params.LastName) ){    
    userValidationError.LastName = "Please enter Last Name";
    isValid = false;
  }else if ( !isAlphaSpace(params.LastName) ){
    userValidationError.LastName = "Last Name should contain only Alphabets";
    isValid = false;
  }else if ( maxLength(50, params.LastName) ){
    userValidationError.LastName = "Last Name must be maximum of 50 characters long";
    isValid = false;
  }

  if ( required(params.Password) ){
    userValidationError.Password = "Please enter Password";
    isValid = false;
  }
  else if(minLength(8,params.Password)) {
    userValidationError.Password = "Password should be 8 characters";
    isValid = false;
  }
  if ( required(params.UserType) ){
    userValidationError.UserType = "Please select UserType";
    isValid = false;
  }

  if (params.UserType==="Acadamic"){
    if (required(params.DocumentUrl) ){
      userValidationError.DocumentUrl = "Please upload the document";
      isValid = false;
    }
  }
  // else if (maxLength(8, params.Password)) {
  //   userValidationError.Password = "Password should be 8 characters.";
  //   isValid = false;
  // }
  if ( required(params.EmailId) ){
    userValidationError.EmailId = "Please enter Email Address";
    isValid = false;
  }else if ( !email(params.EmailId) ){
    userValidationError.EmailId = "Please enter a Valid Email address";
    isValid = false;
  }else if ( !emailUserNameLengthCheck(params.EmailId) ){
    userValidationError.EmailId = "Email address UserName should contain between 1 to 30 characters";
    isValid = false;
  }else if ( maxLength(50, params.EmailId) ){
    userValidationError.EmailId = "Email address must be maximum of 50 characters long";
    isValid = false;
  }
  if (required(params.PhoneNumber)) {
    userValidationError.PhoneNumber = "Phone Number is required";
    isValid = false;
  } else if (!params.PhoneNumber.match(/\d{10,10}$/)) {
    userValidationError.PhoneNumber = "Phone Number should be 10 digits!";
    isValid = false;
  }
  dispatch({type: REGISTER_VALIDATE_FORM, payload: userValidationError, isValid: isValid});
}



export const fileUpload = ( params: any ) : AppThunk => async dispatch => {
  let formData = new FormData();
  formData.append("files", params);
  MakeApiRequest.post("auth/upload", formData,{
    headers: {
    'Content-Type': 'multipart/form-data'
  }})    
    .then((response: { data: any; })=>{    
      dispatch({type: REGISTER_FILE_SUCESS, payload: response.data});
    })
    .catch((errorresponse: any)=>{    
      dispatch({ type: REGISTER_FILE_FAILS, payload: ParseErrorResponse(errorresponse) });
    });  
}



