import MakeApiRequest from "utils/ApiRequest";
import { AppThunk } from "appredux/configureStore";
import { required, isAlphaSpace, maxLength, email, emailUserNameLengthCheck, minLength } from "appredux/common/validationUtils";
import { Error, FormState, Competition } from 'appredux/model/common';
import { ParseErrorResponse } from "appredux/common/utils";
//Types
export interface CompetitionState extends FormState {
  validationErrors: Competition | null,
  url:any | null,
  fileSuccess:any,
  fileError:any
}

// Actions
export const COMPETITION_PROGRESS = 'alsiraj/register/PROGRESS';
export const COMPETITION_INPUT_ENTRY = 'alsiraj/register/INPUT_ENTRY';
export const COMPETITION_VALIDATE_FORM = 'alsiraj/register/VALIDATE_FORM';
export const COMPETITION_FORM_RESET = 'alsiraj/register/FORM_RESET';
export const COMPETITION_SUBMIT = 'alsiraj/register/SUBMIT';
export const COMPETITION_SUBMIT_CLICKED = 'alsiraj/register/SUBMIT/CLICK';
export const COMPETITION_SUCESS = 'alsiraj/register/SUCCESS';
export const COMPETITION_FAILS = 'alsiraj/register/FAILS';


export const COMPETITION_FILE_SUCESS = 'alsiraj/fileupload/SUCCESS';
export const COMPETITION_FILE_FAILS = 'alsiraj/fileupload/FAILS';

interface CompetitionSubmitAction{
  type: typeof COMPETITION_SUBMIT,
  payload: Competition
}

interface CompetitionSubmitClickedAction{
  type: typeof COMPETITION_SUBMIT_CLICKED,
  payload: boolean
}

interface CompetitionProgressAction{
  type: typeof COMPETITION_PROGRESS,
  payload: boolean
}

interface CompetitionSuccessAction{
  type: typeof COMPETITION_SUCESS,
  payload: boolean
}

interface CompetitionFailAction{
  type: typeof COMPETITION_FAILS,
  payload: Error
}

interface CompetitionValidateFormAction{
  type: typeof COMPETITION_VALIDATE_FORM,
  payload: Competition,
  isValid: boolean
}

interface CompetitionFormResetAction{
  type: typeof COMPETITION_FORM_RESET
}

interface CompetitionFileAction{
  type: typeof COMPETITION_FILE_SUCESS,
  payload: any
}

interface CompetitionFileFailAction{
  type: typeof COMPETITION_FILE_FAILS,
  payload: Error
}

export type CompetitionActionTypes = CompetitionSubmitAction | CompetitionSuccessAction | CompetitionFailAction | CompetitionFormResetAction |
                                  CompetitionProgressAction | CompetitionValidateFormAction | CompetitionSubmitClickedAction | CompetitionFileAction | CompetitionFileFailAction ;

const initialState: CompetitionState = {
  loading: null,
  error: null,
  success: null,
  validationErrors: null,
  isFormValid: null,
  isSubmitBtnClicked: null,
  url:null,
  fileSuccess:null,
  fileError:null
};

// Reducer
export default function reducer(state = initialState, action: CompetitionActionTypes) : CompetitionState {
  switch (action.type) {
    case COMPETITION_PROGRESS:
      // Perform action
      return {
        ...state,
        loading: action.payload
      };    
    case COMPETITION_SUBMIT_CLICKED:
      return {
        ...state, 
        isSubmitBtnClicked:action.payload,
      };
    case COMPETITION_VALIDATE_FORM:
      // Perform action
      return {
        ...state,
        validationErrors: action.payload,
        isFormValid: action.isValid
      };
    case COMPETITION_FORM_RESET:
      // Perform action
      return {
        ...state,
        validationErrors: null,
        isFormValid: null,
        isSubmitBtnClicked: null,
        loading: null,
        success: null,
        error: null
      };
    case COMPETITION_FAILS:
      return {
        ...state,
        success: false,
        error: action.payload
      }
    case COMPETITION_SUCESS:
      return {
        ...state,
        success: action.payload,
        error: null
      }
      case COMPETITION_FAILS:
        return {
          ...state,
          success: false,
          error: action.payload
        }
      case COMPETITION_FILE_SUCESS:
        return {
          ...state,
          fileSuccess:true,
          url: action.payload,
        }
        case COMPETITION_FILE_FAILS:
          return {
            ...state,
            fileSuccess:false,
            fileError: action.payload
          }
    default: return state;
  }
}

// Action Creators
export const CompetitionResetForm = () : AppThunk => async dispatch => {
  dispatch({type: COMPETITION_FORM_RESET});
}

export const CompetitionSubmitBtnClicked = (params:boolean) : AppThunk => async dispatch => {
  dispatch({type: COMPETITION_SUBMIT_CLICKED,payload:params});
}

export const SubmitCompetitionation = ( params: Competition ) : AppThunk => async dispatch => {
  dispatch({type: COMPETITION_PROGRESS, payload: true});
  let formattedUserParams: Competition = JSON.parse(JSON.stringify(params));
  MakeApiRequest.post("masters/any/userparticipant/add", formattedUserParams)    
    .then((response: { data: any; })=>{    
      //console.log("success",response.data);
      dispatch({type: COMPETITION_PROGRESS, payload: false});
      dispatch({type: COMPETITION_SUCESS, payload: response.data});
    })
    .catch((errorresponse: any)=>{    
      dispatch({type: COMPETITION_PROGRESS, payload: false});
      dispatch({ type: COMPETITION_FAILS, payload: ParseErrorResponse(errorresponse) });
    });  
}

export const CompetitionValidateForm = (params: Competition) : AppThunk => async dispatch =>{
  let userValidationError = {} as Competition;
  let isValid:boolean = true;
  if ( required(params.Title) ){    
    userValidationError.Title = "Please enter Title";
    isValid = false;
    }
  //else if ( !isAlphaSpace(params.UserName) ){
  //   userValidationError.UserName = "Your Name should contain only Alphabets";
  //   isValid = false;
  // }
  if ( required(params.Date) ){    
    userValidationError.Date = "Please enter Date";
    isValid = false;
  }
  if (required(params.Purpose) ){
    userValidationError.Purpose = "Please enter Purpose";
    isValid = false;
  }

  if (required(params.DocumentLink) ){
    userValidationError.DocumentLink = "Please upload the document";
    isValid = false;
  }
 
  dispatch({type: COMPETITION_VALIDATE_FORM, payload: userValidationError, isValid: isValid});
}



export const fileUpload = ( params: any ) : AppThunk => async dispatch => {
  let formData = new FormData();
  formData.append("files", params);
  MakeApiRequest.post("auth/upload", formData,{
    headers: {
    'Content-Type': 'multipart/form-data'
  }})    
    .then((response: { data: any; })=>{    
      dispatch({type: COMPETITION_FILE_SUCESS, payload: response.data});
    })
    .catch((errorresponse: any)=>{    
      dispatch({ type: COMPETITION_FILE_FAILS, payload: ParseErrorResponse(errorresponse) });
    });  
}



