import MakeApiRequest from "utils/ApiRequest";
import { AppThunk } from "appredux/configureStore";
import { Error, CreateAccount, FormState } from "appredux/model/common";
import { ParseErrorResponse } from "appredux/common/utils";
import {
  required,
  emailUserNameLengthCheck,
  email,
  maxLength,
} from "appredux/common/validationUtils";

//Types
export interface CreateAccountState extends FormState {
  validationErrors: CreateAccount | null;
 }

// Actions
export const CREATEACCOUNT_PROGRESS = "alsiraj/CreateAcc/PROGRESS";
export const CREATEACCOUNT_SUBMIT = "alsiraj/CreateAcc/SUBMIT";
export const CREATEACCOUNT_VALIDATE_FORM = "alsiraj/CreateAcc/VALIDATE_FORM";
export const CREATEACCOUNT_FORM_RESET = "alsiraj/CreateAcc/FORM_RESET";
export const CREATEACCOUNT_SUBMIT_CLICKED = "alsiraj/CreateAcc/SUBMIT/CLICK";
export const CREATEACCOUNT_SUCESS = "alsiraj/CreateAcc/SUCCESS";
export const CREATEACCOUNT_FAILS = "alsiraj/CreateAcc/FAILS";


interface CreateAccSubmitAction {
  type: typeof CREATEACCOUNT_SUBMIT;
  payload: CreateAccount;
}

interface CreateAccSubmitClickedAction {
  type: typeof CREATEACCOUNT_SUBMIT_CLICKED;
  payload: boolean;
}

interface CreateAccValidateFormAction {
  type: typeof CREATEACCOUNT_VALIDATE_FORM;
  payload: CreateAccount;
  isValid: boolean;
}
interface CreateAccProgressAction {
  type: typeof CREATEACCOUNT_PROGRESS;
  payload: boolean;
}

interface CreateAccSuccessAction {
  type: typeof CREATEACCOUNT_SUCESS;
  payload: boolean;
}

interface CreateAccFailAction {
  type: typeof CREATEACCOUNT_FAILS;
  payload: Error;
}
interface CreateAccFormResetAction {
  type: typeof CREATEACCOUNT_FORM_RESET;
}




export type CreateAccActionTypes =
  | CreateAccSubmitAction
  | CreateAccSuccessAction
  | CreateAccFailAction
  | CreateAccSubmitClickedAction
  | CreateAccValidateFormAction
  | CreateAccFormResetAction
  | CreateAccProgressAction;
 
const initialState: CreateAccountState = {
  loading: null,
  error: null,
  success: null,
  validationErrors: null,
  isFormValid: null,
  isSubmitBtnClicked: null,
  };

// Reducer
export default function reducer(
  state = initialState,
  action: CreateAccActionTypes
): CreateAccountState {
  switch (action.type) {
    case CREATEACCOUNT_PROGRESS:
      // Perform action
      return {
        ...state,
        loading: action.payload,
      };
    case CREATEACCOUNT_FAILS:
      return {
        ...state,
        success: false,
        error: action.payload,
        isFormValid: null,
        isSubmitBtnClicked: null
      };
    case CREATEACCOUNT_VALIDATE_FORM:
      return {
        ...state,        
        validationErrors: action.payload,
        isFormValid: action.isValid,
      };
    case CREATEACCOUNT_SUBMIT_CLICKED:
      return {
        ...state,
        isSubmitBtnClicked: action.payload,
      };
    case CREATEACCOUNT_FORM_RESET:
      return {
        ...state,
        validationErrors: null,
        isFormValid: null,
        isSubmitBtnClicked: null,
        loading: null,
        success: null,
        error: null,
      };
    case CREATEACCOUNT_SUCESS:
      return {
        ...state,
        success: action.payload,
        error: null,
        isSubmitBtnClicked: null,
        isFormValid: null
      };
    
    default:
      return state;
  }
}
export const ResetForm = (): AppThunk => async (dispatch) => {  
  dispatch({ type: CREATEACCOUNT_FORM_RESET });
};

export const SubmitBtnClicked = (params: boolean): AppThunk => async (dispatch) => {
  dispatch({ type: CREATEACCOUNT_SUBMIT_CLICKED, payload: params });
};

export const SubmitProfile = (params: CreateAccount): AppThunk => async (dispatch) => {
  dispatch({ type: CREATEACCOUNT_PROGRESS, payload: true });   
      MakeApiRequest.post(
        "masters/any/users/add",
        JSON.parse(JSON.stringify(params))
      )
        .then((response) => {
          //console.log("success",response);
          dispatch({ type: CREATEACCOUNT_PROGRESS, payload: false });
          dispatch({ type: CREATEACCOUNT_SUCESS, payload: response.data.Result });
          dispatch({ type: CREATEACCOUNT_SUBMIT_CLICKED, payload: false });
        })
        .catch((errorresponse) => {
          dispatch({ type: CREATEACCOUNT_PROGRESS, payload: false });
          dispatch({ type: CREATEACCOUNT_SUBMIT_CLICKED, payload: false });
          dispatch({
            type: CREATEACCOUNT_FAILS,
            payload: ParseErrorResponse(errorresponse),
          });
        });
   
};




export const ValidateForm = (params: CreateAccount): AppThunk => async (dispatch) => {
  let errors = {} as CreateAccount;
  let isValid: boolean = true;
      if (required(params.FirstName)) {
    errors.FirstName = "First Name is required";
    isValid = false;
  }
  if (required(params.LastName)) {
    errors.LastName = "Last Name is required";
    isValid = false;
  }
  if (required(params.UserName)) {
    errors.UserName = "User Name is required";
    isValid = false;
  }
  if (required(params.EmailId)) {
    errors.EmailId = "Please enter Email Address";
    isValid = false;
  } else if (!email(params.EmailId)) {
    errors.EmailId = "Please enter a Valid Email address";
    isValid = false;
  } else if (!emailUserNameLengthCheck(params.EmailId)) {
    errors.EmailId =
      "Email address UserName should contain between 1 to 30 characters";
    isValid = false;
  } else if (maxLength(50, params.EmailId)) {
    errors.EmailId = "Email address must be maximum of 50 characters long";
    isValid = false;
  }
  if (required(params.PhoneNumber)) {
    errors.PhoneNumber = "Phone Number is required";
    isValid = false;
  } else if (!params.PhoneNumber.match(/\d{10,10}$/)) {
    errors.PhoneNumber = "Phone Number should be 10 digits!";
    isValid = false;
  }
   dispatch({ type: CREATEACCOUNT_VALIDATE_FORM, payload: errors, isValid: isValid });  
};
