import MakeApiRequest from "utils/ApiRequest";
import { AppThunk } from "appredux/configureStore";
import { required, minLength, maxLength } from "appredux/common/validationUtils";
import { Error, FormState } from 'appredux/model/common';
import { ParseErrorResponse } from "appredux/common/utils";
//Types
export interface User {
  Password: string,
  ConfirmPassword: string,
  WithoutTempPwd?:boolean
}

export interface ResetPasswordState extends FormState {
  validationErrors: User | null
}

// Actions
export const RESET_PWD_PROGRESS = 'alsiraj/resetpassword/PROGRESS';
export const RESET_PWD_INPUT_ENTRY = 'alsiraj/resetpassword/INPUT_ENTRY';
export const RESET_PWD_VALIDATE_FORM = 'alsiraj/resetpassword/VALIDATE_FORM';
export const RESET_PWD_FORM_RESET = 'alsiraj/resetpassword/FORM_RESET';
export const RESET_PWD_SUBMIT = 'alsiraj/resetpassword/SUBMIT';
export const RESET_PWD_SUBMIT_CLICKED = 'alsiraj/resetpassword/SUBMIT/CLICK';
export const RESET_PWD_SUCESS = 'alsiraj/resetpassword/SUCCESS';
export const RESET_PWD_FAILS = 'alsiraj/resetpassword/FAILS';

interface ResetPasswordSubmitAction {
  type: typeof RESET_PWD_SUBMIT,
  payload: User
}

interface ResetPasswordSubmitClickedAction {
  type: typeof RESET_PWD_SUBMIT_CLICKED,
  payload:boolean
}

interface ResetPasswordProgressAction {
  type: typeof RESET_PWD_PROGRESS,
  payload: boolean
}

interface ResetPasswordSuccessAction {
  type: typeof RESET_PWD_SUCESS,
  payload: boolean
}

interface ResetPasswordFailAction {
  type: typeof RESET_PWD_FAILS,
  payload: Error
}

interface ResetPasswordValidateFormAction {
  type: typeof RESET_PWD_VALIDATE_FORM,
  payload: User,
  isValid: boolean
}

interface ResetPasswordFormResetAction {
  type: typeof RESET_PWD_FORM_RESET
}

export type ResetPasswordActionTypes = ResetPasswordSubmitAction | ResetPasswordSuccessAction | ResetPasswordFailAction | ResetPasswordFormResetAction |
                                       ResetPasswordProgressAction | ResetPasswordValidateFormAction | ResetPasswordSubmitClickedAction;

const initialState: ResetPasswordState = {
  loading: null,
  error: null,
  success: null,
  validationErrors: null,
  isFormValid: null,
  isSubmitBtnClicked: null
};

// Reducer
export default function reducer(state = initialState, action: ResetPasswordActionTypes): ResetPasswordState {
  switch (action.type) {
    case RESET_PWD_PROGRESS:
      // Perform action
      return {
        ...state,
        loading: action.payload
      };
    case RESET_PWD_SUBMIT_CLICKED:
      return {
        ...state,
        isSubmitBtnClicked: true
      };
    case RESET_PWD_VALIDATE_FORM:
      // Perform action
      return {
        ...state,
        validationErrors: action.payload,
        isFormValid: action.isValid
      };
    case RESET_PWD_FORM_RESET:
      // Perform action
      return {
        ...state,
        validationErrors: null,
        isFormValid: null,
        isSubmitBtnClicked: null,
        loading: null,
        success: null,
        error: null
      };
    case RESET_PWD_FAILS:
      return {
        ...state,
        success: false,
        error: action.payload
      }
    case RESET_PWD_SUCESS:
      return {
        ...state,
        success: action.payload,
        error: null
      }
    default: return state;
  }
}

// Action Creators
export const ResetForm = (): AppThunk => async dispatch => {
  dispatch({ type: RESET_PWD_FORM_RESET });
}

export const SubmitBtnClicked = (params:boolean): AppThunk => async dispatch => {
  dispatch({ type: RESET_PWD_SUBMIT_CLICKED,payload:params});
}

export const SubmitPasswordChange = (params: User): AppThunk => async dispatch => {
  dispatch({ type: RESET_PWD_PROGRESS, payload: true });
    MakeApiRequest.post("/user/ResetPassword", 
                      null, 
                      {
                        params: {
                          Password : params.Password,
                        }
                      })      
      .then((response: any) => {        
        dispatch({ type: RESET_PWD_PROGRESS, payload: false });
        dispatch({ type: RESET_PWD_SUCESS, payload: response });
      })
      .catch((errorresponse: any) => {      
        dispatch({ type: RESET_PWD_PROGRESS, payload: false });
        dispatch({ type: RESET_PWD_FAILS, payload: ParseErrorResponse(errorresponse) });      
      });
}

export const ValidateForm = (params: User): AppThunk => async dispatch => {
  let userValidationError = {} as User;
  let isValid: boolean = true;
  var upperCaseExpression = /[A-Z]/;
  var lowerCaseExpression = /[a-z]/;
  var NumberExpression = /[0-9]/;
  var specialCaseExpression = /(?=.*\W)/;
  if (required(params.Password)) {
    userValidationError.Password = "Please enter Password";
    isValid = false;
  }else if (!upperCaseExpression.test(params.Password)) {
    userValidationError.Password = 'Password should contain at least one upper case letter.';
    isValid = false;
  }
  else if (!lowerCaseExpression.test(params.Password)) {
    userValidationError.Password = 'Password should contain at least one lower case letter.';
    isValid = false;
  }
  else if (!NumberExpression.test(params.Password)) {
    userValidationError.Password = 'Password should contain at least one numeric value.';
    isValid = false;
  }
  else if (!specialCaseExpression.test(params.Password)) {
    userValidationError.Password = 'Password should contain at least special case character.';
    isValid = false;
  }
  else if(minLength(8,params.Password)) {
    userValidationError.Password = "Password should be 8 characters.";
    isValid = false;
  }
  // else if (maxLength(8, params.Password)) {
  //   userValidationError.Password = "Password should be 8 characters.";
  //   isValid = false;
  // }
  
  if (required(params.ConfirmPassword)) {
    userValidationError.ConfirmPassword = "Please enter Confirm Password";
    isValid = false;
  } else if (!upperCaseExpression.test(params.ConfirmPassword)) {
    userValidationError.ConfirmPassword = 'Confirm Password should contain at least one upper case letter.';
    isValid = false;
  }
  else if (!lowerCaseExpression.test(params.ConfirmPassword)) {
    userValidationError.ConfirmPassword = 'Confirm Password should contain at least one lower case letter.';
    isValid = false;
  }
  else if (!NumberExpression.test(params.ConfirmPassword)) {
    userValidationError.ConfirmPassword = 'Confirm Password should contain at least one numeric value.';
    isValid = false;
  }
  else if (!specialCaseExpression.test(params.ConfirmPassword)) {
    userValidationError.ConfirmPassword = 'Confirm Password should contain at least special case character.';
    isValid = false;
  }
  else if(minLength(8,params.ConfirmPassword)) {
    userValidationError.ConfirmPassword = "Confirm Password should be 8 characters.";
    isValid = false;
  }
  // else if (maxLength(8, params.ConfirmPassword)) {
  //   userValidationError.ConfirmPassword = "ConfirmPassword Password should be 8 characters.";
  //   isValid = false;
  // }
   else if (params.Password != params.ConfirmPassword) {
    userValidationError.ConfirmPassword = "Confirm Password should match with Password";
    isValid = false;
  }
  
  dispatch({ type: RESET_PWD_VALIDATE_FORM, payload: userValidationError, isValid: isValid });
}
