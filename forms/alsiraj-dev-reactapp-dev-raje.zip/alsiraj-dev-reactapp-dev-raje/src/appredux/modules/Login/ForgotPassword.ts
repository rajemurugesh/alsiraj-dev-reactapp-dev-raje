import MakeApiRequest from "utils/ApiRequest";
import { AppThunk } from "appredux/configureStore";
import { required, isAlphaSpace, maxLength, email, emailUserNameLengthCheck, minLength } from "appredux/common/validationUtils";
import { Error, FormState } from 'appredux/model/common';
import { ParseErrorResponse } from "appredux/common/utils";
//Types
export interface User {
  EmailId: string
}

export interface ForgotPasswordState extends FormState {
  validationErrors: User | null
}

// Actions
export const FORGOT_PWD_PROGRESS = 'alsiraj/forgotpwd/PROGRESS';
export const FORGOT_PWD_INPUT_ENTRY = 'alsiraj/forgotpwd/INPUT_ENTRY';
export const FORGOT_PWD_VALIDATE_FORM = 'alsiraj/forgotpwd/VALIDATE_FORM';
export const FORGOT_PWD_FORM_RESET = 'alsiraj/forgotpwd/FORM_RESET';
export const FORGOT_PWD_SUBMIT = 'alsiraj/forgotpwd/SUBMIT';
export const FORGOT_PWD_SUBMIT_CLICKED = 'alsiraj/forgotpwd/SUBMIT/CLICK';
export const FORGOT_PWD_SUCESS = 'alsiraj/forgotpwd/SUCCESS';
export const FORGOT_PWD_FAILS = 'alsiraj/forgotpwd/FAILS';

interface ForgotPasswordSubmitAction{
  type: typeof FORGOT_PWD_SUBMIT,
  payload: User
}

interface ForgotPasswordSubmitClickedAction{
  type: typeof FORGOT_PWD_SUBMIT_CLICKED,
  payload:boolean
}

interface ForgotPasswordProgressAction{
  type: typeof FORGOT_PWD_PROGRESS,
  payload: boolean
}

interface ForgotPasswordSuccessAction{
  type: typeof FORGOT_PWD_SUCESS,
  payload: boolean
}

interface ForgotPasswordFailAction{
  type: typeof FORGOT_PWD_FAILS,
  payload: Error
}

interface ForgotPasswordValidateFormAction{
  type: typeof FORGOT_PWD_VALIDATE_FORM,
  payload: User,
  isValid: boolean
}

interface ForgotPasswordFormResetAction{
  type: typeof FORGOT_PWD_FORM_RESET
}

export type ForgotPasswordActionTypes = ForgotPasswordSubmitAction | ForgotPasswordSuccessAction | ForgotPasswordFailAction | ForgotPasswordFormResetAction |
                                        ForgotPasswordProgressAction | ForgotPasswordValidateFormAction | ForgotPasswordSubmitClickedAction;

const initialState: ForgotPasswordState = {
  loading: null,
  error: null,
  success: null,
  validationErrors: null,
  isFormValid: null,
  isSubmitBtnClicked: null
};

// Reducer
export default function reducer(state = initialState, action: ForgotPasswordActionTypes) : ForgotPasswordState {
  switch (action.type) {
    case FORGOT_PWD_PROGRESS:
      // Perform action
      return {
        ...state,
        loading: action.payload
      };    
    case FORGOT_PWD_SUBMIT_CLICKED:
      return {
        ...state,
        isSubmitBtnClicked: action.payload,
      };
    case FORGOT_PWD_VALIDATE_FORM:
      // Perform action
      return {
        ...state,
        validationErrors: action.payload,
        isFormValid: action.isValid
      };
    case FORGOT_PWD_FORM_RESET:
      // Perform action
      return {
        ...state,
        validationErrors: null,
        isFormValid: null,
        isSubmitBtnClicked: null,
        loading: null,
        success: null,
        error: null
      };
    case FORGOT_PWD_FAILS:
      return {
        ...state,
        success: false,
        error: action.payload
      }
    case FORGOT_PWD_SUCESS:
      return {
        ...state,
        success: action.payload,
        error: null
      }
    default: return state;
  }
}

// Action Creators
export const ResetForm = () : AppThunk => async dispatch => {
  dispatch({type: FORGOT_PWD_FORM_RESET});
}

export const SubmitBtnClicked = (params:boolean) : AppThunk => async dispatch => {
  dispatch({type: FORGOT_PWD_SUBMIT_CLICKED,payload:params});
}

export const SubmitForgotPassword = ( params: User ) : AppThunk => async dispatch => {
  dispatch({type: FORGOT_PWD_PROGRESS, payload: true});
  MakeApiRequest.post("/user/ForgotPassword", 
                    null, 
                    {
                      params:{
                        EmailId: params.EmailId
                      }
                    })
    .then(response=>{          
      dispatch({type: FORGOT_PWD_PROGRESS, payload: false});
      dispatch({type: FORGOT_PWD_SUCESS, payload: response});
    })
    .catch(errorresponse=>{    
      dispatch({type: FORGOT_PWD_PROGRESS, payload: false});  
      dispatch({ type: FORGOT_PWD_FAILS, payload: ParseErrorResponse(errorresponse) });    
    });  
}

export const ValidateForm = (params: User) : AppThunk => async dispatch =>{
  let userValidationError = {} as User;
  let isValid:boolean = true;

  if ( required(params.EmailId) ){
    userValidationError.EmailId = "Please enter Email address";
    isValid = false;
  }else if ( !email(params.EmailId) ){
    userValidationError.EmailId = "Please enter a Valid Email address";
    isValid = false;
  }else if ( !emailUserNameLengthCheck(params.EmailId) ){
    userValidationError.EmailId = "Email address UserName should contain between 1 to 30 characters";
    isValid = false;
  }else if ( maxLength(50, params.EmailId) ){
    userValidationError.EmailId = "Email address must be maximum of 50 characters long";
    isValid = false;
  }

  dispatch({type: FORGOT_PWD_VALIDATE_FORM, payload: userValidationError, isValid: isValid});
}
