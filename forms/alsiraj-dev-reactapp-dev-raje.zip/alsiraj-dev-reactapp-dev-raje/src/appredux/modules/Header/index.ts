import { combineReducers } from "redux";
import Header from './Header';

export default combineReducers({
    Header
});