import MakeApiRequest from "utils/ApiRequest";
import { AppThunk } from "appredux/configureStore";
import { Error, FormState } from "appredux/model/common";
import { ParseErrorResponse } from "appredux/common/utils";

//Types
export interface TrailState extends FormState {
  
}

export const GET_USER_LOGOUT_PROGRESS = "forexweb/USERLOGOUT/PROGRESS";
export const GET_USER_LOGOUT_SUCESS = "forexweb/USERLOGOUT/SUCCESS";
export const GET_USER_LOGOUT_FAILS = "forexweb/USERLOGOUT/FAILS";



interface UserLogoutProgressAction {
  type: typeof GET_USER_LOGOUT_PROGRESS;
  payload: boolean;
}

interface UserLogoutSuccessAction {
  type: typeof GET_USER_LOGOUT_SUCESS;
  payload: any;
}

interface UserLogoutFailAction {
  type: typeof GET_USER_LOGOUT_FAILS;
  payload: Error;
}



export type TrailActionTypes =  UserLogoutProgressAction |
                                 UserLogoutSuccessAction   | UserLogoutFailAction;


const initialState: TrailState = {
  loading: null,
  error: null,
  success: null,
  isFormValid: null,
  isSubmitBtnClicked: null,
};

// Reducer
export default function reducer(
  state = initialState,
  action: TrailActionTypes
): TrailState {
  switch (action.type) {
    case GET_USER_LOGOUT_PROGRESS:
      // Perform action
      return {
        ...state,
        loading: action.payload,
      };
    case GET_USER_LOGOUT_FAILS:
      return {
        ...state,
        success: false,
        error: action.payload,
      };
    case GET_USER_LOGOUT_SUCESS:
      return {
        ...state,
        success: true,        
        error: null,
      };
      default:
      return state;
  }
}


export const Logout = (): AppThunk => async (dispatch) => {
  dispatch({ type: GET_USER_LOGOUT_PROGRESS, payload: true });
  MakeApiRequest.post("/User/SignOut")
    .then((response) => {
      dispatch({ type: GET_USER_LOGOUT_PROGRESS, payload: false });
      dispatch({ type: GET_USER_LOGOUT_SUCESS, payload: response.data.Result });
    })
    .catch((errorresponse) => {
      dispatch({ type: GET_USER_LOGOUT_PROGRESS, payload: false });
      dispatch({
        type: GET_USER_LOGOUT_FAILS,
        payload: ParseErrorResponse(errorresponse),
      });
    });
};