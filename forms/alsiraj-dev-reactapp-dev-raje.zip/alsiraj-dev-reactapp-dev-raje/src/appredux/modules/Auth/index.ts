import { combineReducers } from "redux";
import Dashboard from './Dashboard';










export default combineReducers({
    Dashboard
});