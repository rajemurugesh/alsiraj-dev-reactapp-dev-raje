import MakeApiRequest from "utils/ApiRequest";
import { AppThunk } from "appredux/configureStore";
import { Error, FormState, RegisterUser } from "appredux/model/common";
import { ParseErrorResponse } from "appredux/common/utils";
import { required, maxLength, email, emailUserNameLengthCheck, minLength } from "appredux/common/validationUtils";

//Types
export interface User {
  EmailId: string,
  Password?: any
}



export interface LoginState extends FormState {
  validationErrors: User | null,
}

// Actions
export const LOGIN_PROGRESS = 'alsiraj/login/PROGRESS';
export const LOGIN_INPUT_ENTRY = 'alsiraj/login/INPUT_ENTRY';
export const LOGIN_VALIDATE_FORM = 'alsiraj/login/VALIDATE_FORM';
export const LOGIN_FORM_RESET = 'alsiraj/login/FORM_RESET';
export const LOGIN_SUBMIT = 'alsiraj/login/SUBMIT';
export const LOGIN_SUBMIT_CLICKED = 'alsiraj/login/SUBMIT/CLICK';
export const LOGIN_SUCESS = 'alsiraj/login/SUCCESS';
export const LOGIN_FAILS = 'alsiraj/login/FAILS';








interface LoginSubmitAction {
  type: typeof LOGIN_SUBMIT,
  payload: User
}

interface LoginSubmitClickedAction {
  type: typeof LOGIN_SUBMIT_CLICKED,
  payload:boolean
}

interface LoginProgressAction {
  type: typeof LOGIN_PROGRESS,
  payload: boolean
}

interface LoginSuccessAction {
  type: typeof LOGIN_SUCESS,
  payload: boolean
}

interface LoginFailAction {
  type: typeof LOGIN_FAILS,
  payload: Error
}

interface LoginValidateFormAction {
  type: typeof LOGIN_VALIDATE_FORM,
  payload: User,
  isValid: boolean
}

interface LoginFormResetAction {
  type: typeof LOGIN_FORM_RESET
}


export type LoginActionTypes = LoginSubmitAction | LoginSuccessAction | LoginFailAction | LoginFormResetAction |
  LoginProgressAction | LoginValidateFormAction | LoginSubmitClickedAction  ;

const initialState: LoginState = {
  loading: null,
  error: null,
  success: null,
  validationErrors: null,
  isFormValid: null,
  isSubmitBtnClicked: null,
 
};

// Reducer
export default function reducer(state = initialState, action: LoginActionTypes): LoginState {
  switch (action.type) {
    case LOGIN_PROGRESS:
      // Perform action
      return {
        ...state,
        loading: action.payload
      };
    case LOGIN_SUBMIT_CLICKED:
      return {
        ...state,
        isSubmitBtnClicked:action.payload,
      };
    case LOGIN_VALIDATE_FORM:
      // Perform action
      return {
        ...state,
        validationErrors: action.payload,
        isFormValid: action.isValid
      };
    case LOGIN_FORM_RESET:
      // Perform action
      return {
        ...state,
        validationErrors: null,
        isFormValid: null,
        isSubmitBtnClicked: null,
        loading: null,
        success: null,
        error: null
      };
    case LOGIN_FAILS:
      return {
        ...state,
        success: false,
        error: action.payload
      }
    case LOGIN_SUCESS:
      return {
        ...state,
        success: action.payload,
        error: null
      }
  
    default: return state;
  }
}

// Action Creators
export const ResetForm = (): AppThunk => async dispatch => {
  dispatch({ type: LOGIN_FORM_RESET });
}

export const SubmitloginBtnClicked = (params:boolean): AppThunk => async dispatch => {
  dispatch({ type: LOGIN_SUBMIT_CLICKED,payload:params });
}

export const SubmitLogin = (params: User): AppThunk => async dispatch => {
  dispatch({ type: LOGIN_PROGRESS, payload: true });
  MakeApiRequest.post('auth/signin', params)
    .then(response => {
      dispatch({ type: LOGIN_PROGRESS, payload: false });
      dispatch({ type: LOGIN_SUCESS, payload: response.data });
    })
    .catch(errorresponse => {
      dispatch({ type: LOGIN_PROGRESS, payload: false });
      dispatch({ type: LOGIN_FAILS, payload: ParseErrorResponse(errorresponse) });
    });
}

export const ValidateForm = (params: User): AppThunk => async dispatch => {
  let userValidationError = {} as User;
  let isValid: boolean = true;
  var upperCaseExpression = /[A-Z]/;
  var lowerCaseExpression = /[a-z]/;
  var NumberExpression = /[0-9]/;
  var specialCaseExpression = /(?=.*\W)/;

  if (required(params.Password)) {
    userValidationError.Password = "Please enter Password";
    isValid = false;
  }
  else if (!upperCaseExpression.test(params.Password)) {
    userValidationError.Password = 'Password should contain at least one upper case letter.';
    isValid = false;
  }
  else if (!lowerCaseExpression.test(params.Password)) {
    userValidationError.Password = 'Password should contain at least one lower case letter.';
    isValid = false;
  }
  else if (!NumberExpression.test(params.Password)) {
    userValidationError.Password = 'Password should contain at least one numeric value.';
    isValid = false;
  }
  else if (!specialCaseExpression.test(params.Password)) {
    userValidationError.Password = 'Password should contain at least special case character.';
    isValid = false;
  }
  else if(minLength(8,params.Password)) {
    userValidationError.Password = "Password should be 8 characters.";
    isValid = false;
  }
  if (required(params.EmailId)) {
    userValidationError.EmailId = "Please enter Email address";
    isValid = false;
  } else if (!email(params.EmailId)) {
    userValidationError.EmailId = "Please enter a Valid Email address";
    isValid = false;
  } else if (!emailUserNameLengthCheck(params.EmailId)) {
    userValidationError.EmailId = "Email address UserName should contain between 1 to 30 characters";
    isValid = false;
  } else if (maxLength(50, params.EmailId)) {
    userValidationError.EmailId = "Email address must be maximum of 50 characters long";
    isValid = false;
  }

  dispatch({ type: LOGIN_VALIDATE_FORM, payload: userValidationError, isValid: isValid });
}






