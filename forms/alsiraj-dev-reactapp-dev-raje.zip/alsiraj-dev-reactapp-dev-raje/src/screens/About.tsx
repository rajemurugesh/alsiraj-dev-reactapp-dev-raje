import React, { Component } from "react";
import Header from "containers/Header/Header";
import Footer from "components/footer";
import { Link, Redirect } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { AboutScreenPropsFromRedux } from "containers/About";
import { useTranslation,withTranslation } from 'react-i18next';

interface IProps { t?:any}
interface IState {
    goToAuth: boolean,
    goToUrl?: string,
   
}

type Props = AboutScreenPropsFromRedux & IProps;
export default withTranslation('default') (class AboutScreen extends Component<Props, IState>{
    constructor(props: Props) {
        super(props);
        this.state = {
            goToAuth: false,
        };
    }

    async componentDidMount() {
    }

    componentDidUpdate(prevProps: Props) {
        //screenWidth = Dimensions.get("window");
        
    }

  




    render() {
      const {t} = this.props;
        if (this.state.goToAuth === true) {
            return <Redirect to={`${process.env.PUBLIC_URL}/${this.state.goToUrl}`} push={true} />
        }
        return (
          <React.Fragment>
              <Header authenticated={this.props.session.checked && this.props.session.authenticated}></Header>
            <React.Fragment>
              <ToastContainer
                position="top-center"
                hideProgressBar={false}
                autoClose={false}
                newestOnTop={true}
                closeOnClick={false}
                draggable={false}
                rtl={false}
              />
            </React.Fragment>
            <main id="main">
              <section className="breadcrumbs">
                <div className="container">
                  <div className="d-flex justify-content-between align-items-center">
                    <h2>{t("menu-about")}</h2>
                    <ol>
                      <li>
                        {" "}
                        <Link to={`${process.env.PUBLIC_URL}/`}>{t("menu-home")}</Link>
                      </li>
                      <li>{t("menu-about")}</li>
                    </ol>
                  </div>
                </div>
              </section>
              <section className="about" data-aos="fade-up">
                <div className="container">
                  <div className="row">
                    <div className="col-lg-12 pt-6 pt-lg-0">
                      <p className="font-italic">
                      {t("about1")}
                        
                      </p>
                      <p className="font-italic">
                      {t("about2")}
                      
                      </p>
                      <p className="font-italic">
                      {t("about3")}
                      </p>
                    </div>
                  </div>
                </div>
              </section>
              <section className="testimonials"></section>
            </main>

            <Footer></Footer>
          </React.Fragment>
        );
    }
})