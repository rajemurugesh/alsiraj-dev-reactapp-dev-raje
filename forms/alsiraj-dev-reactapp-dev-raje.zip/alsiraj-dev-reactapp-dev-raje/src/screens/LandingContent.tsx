import React, { Component } from "react";
import Header from "containers/Header/Header";
import Footer from "components/footer";
import { Link, Redirect } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { LandingContentScreenPropsFromRedux } from "containers/LandingContent";

interface IProps { }
interface IState {
    goToAuth: boolean;
    goToUrl?: string;
}

type Props = LandingContentScreenPropsFromRedux & IProps;
export default class LandingContentScreen extends Component<Props, IState> {
    constructor(props: Props) {
        super(props);
        this.state = {
            goToAuth: false,
        };
    }

    async componentDidMount() { }

    componentDidUpdate(prevProps: Props) { }

    render() {
        if (this.state.goToAuth === true) {
            return (
                <Redirect
                    to={`${process.env.PUBLIC_URL}/${this.state.goToUrl}`}
                    push={true}
                />
            );
        }
        return (
            <React.Fragment>
                <Header
                    authenticated={
                        this.props.session.checked && this.props.session.authenticated
                    }
                ></Header>
                <React.Fragment>
                    <ToastContainer
                        position="top-center"
                        hideProgressBar={false}
                        autoClose={false}
                        newestOnTop={true}
                        closeOnClick={false}
                        draggable={false}
                        rtl={false}
                    />
                </React.Fragment>
                <main id="main">
                    <section className="about services">
                        <div className="container">
                            <div className=" row">
                                <div className="col-md-6 col-lg-4 " data-aos="fade-up">
                                    <div className="icon-box icon-box-pink">
                                        <div className="icon">
                                            <i className="bx bx-paint"></i>
                                        </div>
                                        <h4 className="title">
                                            <a href={`${process.env.PUBLIC_URL}/landingcontent`}>Design & Development</a>
                                        </h4>
                                        <p className="description">Business Applications</p>
                                        <p className="description">Website & Portal</p>
                                        <p className="description">Identity, Posters & Gifts</p>
                                    </div>
                                </div>

                                <div
                                    className="col-md-6 col-lg-4"
                                    data-aos="fade-up"
                                    data-aos-delay="100"
                                >
                                    <div className="icon-box icon-box-cyan">
                                        <div className="icon">
                                            <i className="bx bx-file"></i>
                                        </div>
                                        <h4 className="title">
                                            <a href={`${process.env.PUBLIC_URL}/landingcontent`}>Consultation</a>
                                        </h4>
                                        <p className="description">
                                            Business Planning, Management & Strategy
                    </p>
                                        <p className="description">Information System</p>
                                        <p className="description">
                                            Infrastructures & Cyber Security
                    </p>
                                    </div>
                                </div>

                                <div
                                    className="col-md-6 col-lg-4"
                                    data-aos="fade-up"
                                    data-aos-delay="200"
                                >
                                    <div className="icon-box icon-box-green">
                                        <div className="icon">
                                            <i className="bx bx-tachometer"></i>
                                        </div>
                                        <h4 className="title">
                                            <a href={`${process.env.PUBLIC_URL}/landingcontent`}>Software & Application Solution</a>
                                        </h4>
                                        <p className="description">
                                            Al-​Siraj offers differents software and application
                                            solution, Some of them are owned by Al-Siraj while others
                                            are partnerships with other institutions in the field of
                                            designing and developing information systems.
                    </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </main>

                <Footer></Footer>
            </React.Fragment>
        );
    }
}
