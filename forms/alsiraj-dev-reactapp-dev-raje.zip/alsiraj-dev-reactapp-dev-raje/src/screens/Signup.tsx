import React, { Component } from "react";
import Header from "containers/Header/Header";
import Footer from "components/footer";
import { Link, Redirect } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { SignupScreenPropsFromRedux } from "containers/Signup";
import InputMask from 'react-input-mask';
import { toast } from "react-toastify";
import Select from "react-select";
interface IProps {
  navigation: any;
}
interface IState {
  goToAuth: boolean,
  goToUrl?: string,
  yourName: string,
  emailAddress: string,
  password: string,
  firstname: string,
  lastname: string,
  email: string,
  phonenumber: string,
  userType: any,
  documentLink: string

}

type Props = SignupScreenPropsFromRedux & IProps;
export default class SignupScreen extends Component<Props, IState>{
  constructor(props: Props) {
    super(props);
    this.state = {
      goToAuth: false,
      yourName: "",
      emailAddress: "",
      password: "",
      firstname: '',
      lastname: '',
      email: '',
      phonenumber: '',
      userType: 'Acadamic',
      documentLink: ''

    };
  }

  componentDidUpdate(prevProps: Props) {
    if (this.props.register.loading != null) {
      if (prevProps.register.loading != this.props.register.loading) {
        this.ToggleLoadingScreen();
      }
    }

    if (!this.props.register?.success && this.props.register?.error != null) {
      if (prevProps.register?.error != this.props.register?.error) {
        this.ShowErrorMessage(this.props.register.error.ExceptionMessage.toString());
      }
    } else if (this.props.register?.success) {
      if (prevProps.register.success != this.props.register.success) {
        this.ShowSuccessMessage();
      }
    }


    if (!this.props.register?.fileSuccess && this.props.register?.fileError != null) {
      if (prevProps.register?.fileError != this.props.register?.error) {
        this.ShowErrorMessage(this.props.register.fileError.ExceptionMessage.toString());
      }
    } else if (this.props.register?.fileSuccess) {
      if (prevProps.register.fileSuccess != this.props.register.fileSuccess) {

        this.setState({ documentLink: this.props.register?.url?.filePath! })
      }
    }


  }

  componentDidMount() {
  }


  ShowErrorMessage = (errorMessage: string) => {
    toast.error(errorMessage, {
      autoClose: false,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: false,
      progress: false,
    });
  }
  ShowSuccessMessage = async () => {
    // toast.success("You have been successfully registered!!!", {
    //   autoClose: false,
    //   hideProgressBar: true,
    //   closeOnClick: true,
    //   pauseOnHover: true,
    //   draggable: false,
    //   progress: false,
    // });
    setTimeout(() => {
      this.setState({
        goToAuth: true,
        goToUrl: 'login'
      });
    }, 2000);
    this.props.RegUserSubmitBtnClicked(false);
  }

  ToggleLoadingScreen = () => {
    if (this.props.register.loading) {
      window.jQuery('#dataloader').show();
    } else {
      window.jQuery('#dataloader').hide();
    }
  }


  GoToAuth = () => {
    this.props.RegUserResetForm();
    this.props.RegUserSubmitBtnClicked(true);
    this.ValidateForm();
    setTimeout(() => this.SubmitForm(), 0);
  }


  handleKeyDown = (event: any) => {
    console.log(event);
    if (event.key === 'Enter') {
      event.preventDefault();
      this.GoToAuth()
    }
  }

  SubmitForm = () => {
    if (this.props.register?.isSubmitBtnClicked && this.props.register?.isFormValid) {
      //this.Loader(true);
      this.props.SubmitUserDetails({
        UserName: this.state.yourName,
        FirstName: this.state.firstname,
        LastName: this.state.lastname,
        Password: this.state.password,
        EmailId: this.state.emailAddress,
        PhoneNumber: this.state.phonenumber,
        AppUser: 'appuser',
        UserType: this.state.userType["value"],
        DocumentUrl: this.state.documentLink
      });
    }
  }

  ValidateForm = () => {
    this.props.RegUserValidateForm({
      UserName: this.state.yourName,
      FirstName: this.state.firstname,
      LastName: this.state.lastname,
      Password: this.state.password,
      EmailId: this.state.emailAddress,
      PhoneNumber: this.state.phonenumber,
      UserType: this.state.userType["value"],
      DocumentUrl: this.state.documentLink
    });
  }

  keyPress = (event?: any, type?: string) => {
    event.persist();
    if (this.props?.register?.isSubmitBtnClicked) {
      this.ValidateForm();
    }
  }
  textChange = (event: any, type: string) => {
    switch (type) {
      case "UserName":
        this.setState({ 'yourName': event.target.value });
        break;
      case 'Password':
        this.setState({ 'password': event.target.value });
        break;
      case 'EmailId':
        this.setState({ 'emailAddress': event.target.value });
        break;
      case 'phonenumber':
        this.setState({ 'phonenumber': event.target.value });
        break;
      case "firstname":
        this.setState({ firstname: event.target.value });
        break;
      case "lastname":
        this.setState({ lastname: event.target.value });
        break;
    }


  }


  drowpDownChange = (event: any, type: string) => {
    //console.log("type", type);
    switch (type) {
      case "userType":
        this.setState({ userType: event});
        break;
    }
  };

  importFile = (e: any) => {
    let file = e.target.files[0];
    this.props.fileUpload(file);
  }






  render() {

    if (this.state.goToAuth === true) {
      return <Redirect to={`${process.env.PUBLIC_URL}/${this.state.goToUrl}`} push={true} />
    }
    return (
      <React.Fragment>
        <Header
        ></Header>
        <React.Fragment>
          <ToastContainer
            position="top-center"
            hideProgressBar={false}
            autoClose={false}
            newestOnTop={true}
            closeOnClick={false}
            draggable={false}
            rtl={false}
          />
        </React.Fragment>
        <main id="main">
          <section className="breadcrumbs">
            <div className="container">
              <div className="d-flex justify-content-between align-items-center">
                <h2>Register</h2>
                <ol>
                  <li>
                    {" "}
                    <Link to={`${process.env.PUBLIC_URL}/`}>Home</Link>
                  </li>
                  <li> Register</li>
                </ol>
              </div>
            </div>
          </section>
          <section className="about" data-aos="fade-up">
            <div className="container">
              <div className="row">
                <section
                  className="contact"
                  data-aos="fade-up"
                  data-aos-easing="ease-in-out"
                  data-aos-duration="500"
                >
                  <div className="container">
                    <div className="row justify-content-center">
                      <div className="col-lg-6 center-block">
                        <div className="info-box">
                          <i className="bx bx-user"></i>
                          <h3>
                            Create Account
                </h3>
                          <div className="col-lg-12">
                            <div
                              role="form"
                              style={{ boxShadow: 'none' }}
                              className="php-email-form"
                            >
                              <div className="form-group mt-3 mb-3">
                                <input
                                  type="text"
                                  className="form-control"
                                  name="username"
                                  id="subject"
                                  required={true} placeholder="Enter your Name" onChange={(text) => this.textChange(text, 'UserName')} onKeyPress={(e: any) => this.handleKeyDown(e)} value={this.state.yourName} onKeyUp={(event) => this.keyPress(event, 'UserName')}
                                />
                                <div className="invalid-feedback ">{this.props.register?.validationErrors?.UserName}</div>
                              </div>

                              <div className="row">
                                <div className="col-md-6 form-group">
                                  <input
                                    type="text"
                                    onKeyUp={(e: any) => this.keyPress(e)}
                                    onChange={(text) =>
                                      this.textChange(text, "firstname")
                                    }
                                    onKeyPress={(e: any) => this.handleKeyDown(e)}
                                    value={this.state.firstname}
                                    name="name"
                                    className="form-control"
                                    id="name"
                                    placeholder="First Name"
                                  />
                                  <div className="invalid-feedback ">{this.props.register?.validationErrors?.FirstName}</div>
                                </div>
                                <div className="col-md-6 form-group mt-3 mt-md-0">
                                  <input
                                    type="text"
                                    onKeyUp={(e: any) => this.keyPress(e)}
                                    onChange={(text) =>
                                      this.textChange(text, "lastname")
                                    }
                                    onKeyPress={(e: any) => this.handleKeyDown(e)}
                                    value={this.state.lastname}
                                    className="form-control"
                                    name="email"
                                    id="email"
                                    placeholder="Last Name"
                                  />
                                  <div className="invalid-feedback ">{this.props.register?.validationErrors?.LastName}</div>
                                </div>
                              </div>
                              <div className="form-group mt-3">
                                <Select
                                  onKeyPress={(e: any) => this.keyPress(e)}
                                  options={[{ label: 'Acadamic', value: "Acadamic" }, { label: 'Public', value: "Public" }]}
                                  onChange={(e: any) =>
                                    this.drowpDownChange(e, "userType")
                                  }
                                  value={this.state.userType}
                                  arrowClosed={<span className="arrow-closed" />}
                                  arrowOpen={<span className="arrow-open" />}
                                  placeholder="Select an option"
                                />
                                <div className="invalid-feedback ">{this.props.register?.validationErrors?.UserType}</div>
                              </div>
                              {
                                this.state.userType["value"] === "Acadamic" ?

                                  <div className="form-group mt-3">
                                    <input type="file" className="form-control" onChange={(e) => this.importFile(e)} id="customFile"></input>
                                    <div className="invalid-feedback ">{this.props.register?.validationErrors?.DocumentUrl}</div>
                                  </div>
                                  :   null
                              }


                              <div className="form-group mt-3">
                                <input
                                  type="email"
                                  className="form-control"
                                  name="email"
                                  onKeyPress={(e: any) => this.handleKeyDown(e)}
                                  value={this.state.emailAddress}
                                  onChange={(text) => this.textChange(text, 'EmailId')}
                                  onKeyUp={(event) => this.keyPress(event, 'EmailId')}
                                  id="email"
                                  placeholder="Email Id"
                                />
                                <div className="invalid-feedback ">{this.props.register?.validationErrors?.EmailId}</div>
                              </div>
                              <div className="form-group mt-3">
                                <input type="password" required={true} placeholder="Enter Password" value={this.state.password}
                                  onChange={(text) => this.textChange(text, 'Password')}
                                  onKeyPress={(e: any) => this.handleKeyDown(e)}
                                  onKeyUp={(event) => this.keyPress(event, 'Password')} name="signup-username" id="signup-username" className="form-control" aria-required="true" />
                                <div className="invalid-feedback "> {this.props.register?.validationErrors?.Password}</div>
                              </div>
                              <div className="form-group mt-3">
                                <InputMask className="form-control" onKeyPress={(e: any) => this.handleKeyDown(e)}
                                  mask="9999999999"
                                  type="text"
                                  maskChar={"_"}
                                  onKeyUp={(e: any) => this.keyPress(e)}
                                  onChange={(text: any) =>
                                    this.textChange(text, "phonenumber")
                                  }
                                  required={true} placeholder="Phone Number">

                                </InputMask>
                                <div className="invalid-feedback ">{this.props.register?.validationErrors?.PhoneNumber}</div>
                              </div>
                              <div className="mb-4">
                                <div className="loading">Loading</div>
                                <div className="error-message"></div>
                                <div className="sent-message">
                                  Your message has been sent. Thank you!
                      </div>
                              </div>
                              <div className="text-center">
                                <button type="submit" onClick={this.GoToAuth} >Signup Now</button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </section>

              </div>
            </div>
          </section>
          <section className="testimonials"></section>
        </main>

        <Footer></Footer>
      </React.Fragment>
    );
  }
}