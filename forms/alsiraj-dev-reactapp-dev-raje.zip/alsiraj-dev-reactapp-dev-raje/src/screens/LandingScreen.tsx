import React, { Component } from "react";
import Header from "containers/Header/Header";
import Footer from "components/footer";
import { Redirect } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { LandingScreenPropsFromRedux } from "containers/LandingScreen";
import MakeApiRequest from "utils/ApiRequest";
import StorageManagement from "utils/StorageManagement";
import Marquee from "react-fast-marquee";
import { useTranslation,withTranslation } from 'react-i18next';

interface IProps { t?:any}
interface IState {
  goToAuth: boolean;
  goToUrl?: string;
  compList: Array<any>,
  AppUser: string,
  lefti: number
}

type Props = LandingScreenPropsFromRedux & IProps;
export default withTranslation('default') (class LandingScreen extends Component<Props, IState> {
  constructor(props: Props) {
    super(props);  
    this.state = {
      goToAuth: false,
      compList: [],
      AppUser: "",
      lefti: 450
    };
    //const { t } = useTranslation();
  }

  async componentDidMount() {
    let userData = await StorageManagement.getUserData();
    if (userData) {
      this.setState({
        AppUser: userData ?.AppUser!
      });

    }

    this.getCompList()
  }

  getCompList = () => {
    MakeApiRequest.post('masters/any/competition/list', {})
      .then(response => {
        if (response ?.status) {

          let result = response ?.data ?.data;
          this.setState({ "compList": result });
          //location.reload();
        }
      })
      .catch(errorresponse => {

      });
  }

  componentDidUpdate(prevProps: Props) {
    //screenWidth = Dimensions.get("window");
  }

  participateComp = (name: any) => {

    if (this.state.AppUser != "") {
      sessionStorage.setItem("CompetitionType", name);
      this.setState({
        goToAuth: true,
        goToUrl: 'participation?type=' + name
      })
    }
    else {
      this.setState({
        goToAuth: true,
        goToUrl: 'login?type=' + name
      })
    }

  }

  GotoCompetion = (type: any) => {

    switch (type) {
      case "gold":
        window.jQuery('.modal-backdrop').remove();
        window.jQuery('.modal-backdrop').remove();
        sessionStorage.setItem("CompetitionType", "gold");
        this.setState({
          goToAuth: true,
          goToUrl: 'participation?type=gold'
        })
        break;
      case "silver":
        window.jQuery('.modal-backdrop').remove();
        window.jQuery("#silverAward").hide();
        sessionStorage.setItem("CompetitionType", "silver");
        this.setState({
          goToAuth: true,
          goToUrl: 'participation?type=silver'
        })
        break;
      case "bronze":
        window.jQuery('.modal-backdrop').remove();
        window.jQuery("#bronzeAward").hide();
        sessionStorage.setItem("CompetitionType", "bronze");
        this.setState({
          goToAuth: true,
          goToUrl: 'participation?type=bronze'
        })
        break;
    }
  }

  render() {
    const {t} = this.props;
    
    if (this.state.goToAuth === true) {
      return (
        <Redirect
          to={`${process.env.PUBLIC_URL}/${this.state.goToUrl}`}
          push={true}
        />
      );
    }
    return (
      <React.Fragment>
        <Header authenticated={this.props.session.checked && this.props.session.authenticated}></Header>
        <React.Fragment>
          <ToastContainer
            position="top-center"
            hideProgressBar={false}
            autoClose={false}
            newestOnTop={true}
            closeOnClick={false}
            draggable={false}
            rtl={false}
          />
        </React.Fragment>

        <section style={ this.state.AppUser != "adminuser" ? {marginTop:0} : {marginTop:80}}
          id="hero"
          className="d-flex justify-cntent-center align-items-center"
        >
         
          <div
            id="heroCarousel"
            className="container carousel carousel-fade"
            data-bs-ride="carousel"
            data-bs-interval="5000"
          >
           {
            this.state.AppUser != "adminuser"
              ?
              (

                <div id="breaking-news-container">
                  <Marquee style={{ backgroundColor: 'transparent', color: 'firebrick',zIndex:1 }}
                    gradientWidth="600" speed={40}
                  >
                    {this.state.compList.map((key, index) => (

                      <a href="javascript:void(0)" className="welcome-text"
                        onClick={() => this.participateComp(key["_id"])}  >
                        {key.description}
                      </a>

                    ))}
                  </Marquee>




                </div>
              )
              :
              ''

          }
            <div className="carousel-item active">
              <div className="carousel-container">
                <h2 className="animate__animated animate__fadeInDown">
                 {t("welcome")} <span>Al-Siraj</span>
                </h2>
                <p className="animate__animated animate__fadeInUp">
                {t("welcometext")} 
                </p>
                <a
                  href={`${process.env.PUBLIC_URL}/landingcontent`}
                  className="btn-get-started animate__animated animate__fadeInUp"
                >
                  {t("read-more")}
                </a>
              </div>
            </div>

            <div className="carousel-item">
              <div className="carousel-container">
                <h2 className="animate__animated animate__fadeInDown">
                {t("welcome")} <span>Al-Siraj</span>
                </h2>
                <p className="animate__animated animate__fadeInUp">
                {t("welcometext")} 
                </p>
                <a
                  href={`${process.env.PUBLIC_URL}/landingcontent`}
                  className="btn-get-started animate__animated animate__fadeInUp"
                >
                  {t("read-more")}
                </a>
              </div>
            </div>

            <div className="carousel-item">
              <div className="carousel-container">
                <h2 className="animate__animated animate__fadeInDown">
                {t("welcome")} <span>Al-Siraj</span>
                </h2>
                <p className="animate__animated animate__fadeInUp">
                {t("welcometext")} 
                </p>
                <a
                  href={`${process.env.PUBLIC_URL}/landingcontent`}
                  className="btn-get-started animate__animated animate__fadeInUp"
                >
                  {t("read-more")}
                </a>
              </div>
            </div>

            <a
              className="carousel-control-prev"
              href="#heroCarousel"
              role="button"
              data-bs-slide="prev"
            >
              <span
                className="carousel-control-prev-icon bx bx-chevron-left"
                aria-hidden="true"
              ></span>
              <span className="sr-only">Previous</span>
            </a>

            <a
              className="carousel-control-next"
              href="#heroCarousel"
              role="button"
              data-bs-slide="next"
            >
              <span
                className="carousel-control-next-icon bx bx-chevron-right"
                aria-hidden="true"
              ></span>
              <span className="sr-only">Next</span>
            </a>
          </div>
        </section>

        <main id="main" style={{marginTop:-20}}>
          <section className="about services">
            <div className="container">
              <div className=" row">
                <div className="col-md-6 col-lg-4 " data-aos="fade-up">
                  <div className="icon-box icon-box-pink">
                    <div className="icon">
                      <i className="bx bx-paint"></i>
                    </div>
                    <h4 className="title">
                      <a  href={`${process.env.PUBLIC_URL}/landingcontent`}> {t("service-1")} </a>
                    </h4>
                    <p className="description">{t("service-2")}</p>
                    <p className="description">{t("service-3")}</p>
                    <p className="description">{t("service-4")}</p>
                  </div>
                </div>

                <div
                  className="col-md-6 col-lg-4"
                  data-aos="fade-up"
                  data-aos-delay="100"
                >
                  <div className="icon-box icon-box-cyan">
                    <div className="icon">
                      <i className="bx bx-file"></i>
                    </div>
                    <h4 className="title">
                      <a  href={`${process.env.PUBLIC_URL}/landingcontent`}>{t("service1-1")}</a>
                    </h4>
                    <p className="description">
                    {t("service1-2")}
                    </p>
                    <p className="description">{t("service1-3")}</p>
                    <p className="description">
                    {t("service1-4")}
                    </p>
                  </div>
                </div>

                <div
                  className="col-md-6 col-lg-4"
                  data-aos="fade-up"
                  data-aos-delay="200"
                >
                  <div className="icon-box icon-box-green">
                    <div className="icon">
                      <i className="bx bx-tachometer"></i>
                    </div>
                    <h4 className="title">
                      <a href={`${process.env.PUBLIC_URL}/landingcontent`}> {t("service2-1")}</a>
                    </h4>
                    <p className="description">
                    {t("service2-2")}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="features services" style={{padding:1}}>
            <div className="container">
              <div className="section-title">
                <h2> {t("comp")} </h2>


                <p style={{fontSize:14}}>
                {t("comp-text")}
                </p>
              </div>
              <div className="container">
                <div className="row">
                  <div className="col-md-6 col-lg-4 " data-aos="fade-up">
                    <div
                      className="card"
                      style={{
                        minHeight: 80,
                        textAlign: "center",
                        border: "none",
                        display: "block",
                      }}
                    >
                      <a
                        href=""
                        data-bs-toggle="modal"
                        data-bs-target="#goldAward"
                      >
                        <img
                          src={`${process.env.PUBLIC_URL}/img/awards/gold.png`}
                        ></img>
                        <h4 style={{ marginTop: 15 }} className="title">
                          <span>{t("golden")}</span>
                        </h4>
                      </a>
                    </div>
                  </div>

                  <div
                    className="col-md-6 col-lg-4"
                    data-aos="fade-up"
                    data-aos-delay="100"
                  >
                    <div
                      className="card"
                      style={{
                        minHeight: 80,
                        textAlign: "center",
                        border: "none",
                        display: "block",
                      }}
                    >
                      <a
                        href=""
                        data-bs-toggle="modal"
                        data-bs-target="#silverAward"
                      >
                        <img
                          src={`${process.env.PUBLIC_URL}/img/awards/silver.png`}
                        ></img>
                        <h4 style={{ marginTop: 15 }} className="title">
                          <span>{t("silver")}</span>
                        </h4>
                      </a>
                    </div>
                  </div>

                  <div
                    className="col-md-6 col-lg-4"
                    data-aos="fade-up"
                    data-aos-delay="200"
                  >
                    <div
                      className="card"
                      style={{
                        minHeight: 80,
                        textAlign: "center",
                        border: "none",
                        display: "block",
                      }}
                    >
                      <a
                        href=""
                        data-bs-toggle="modal"
                        data-bs-target="#bronzeAward"
                      >
                        <img
                          src={`${process.env.PUBLIC_URL}/img/awards/bronze.png`}
                        ></img>
                        <h4 style={{ marginTop: 15 }} className="title">
                          <span>{t("bronze")}</span>
                        </h4>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <section className="features services"></section>
        </main>
        <React.Fragment>
          <div
            id="goldAward"
            className="TradeSubscription_scroll modal fade align-middle"
            role="dialog"
          >
            <div className="modal-dialog modal-dialog-centered modal-lg">
              <div className="modal-content">
                <div className="modal-header">
                  <h4 className="modal-title">{t("golden")} </h4>
                  <button
                    type="button"
                    className="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                  ></button>
                </div>
                <div className="modal-body">
                  <div className="row  php-email-form">
                    <p>
                      {t("golden-text")}
                    </p>
                    {/* <div className="text-center mt-4"><button style={{backgroundColor:'#68A4C4',width:150}} onClick={()=>this.GotoCompetion("gold")} name="submit" id="form-submit" type="submit" className="btn btn-md btn-black">Participation</button></div> */}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div
            id="silverAward"
            className="TradeSubscription_scroll modal fade align-middle"
            role="dialog"
          >
            <div className="modal-dialog modal-dialog-centered modal-lg">
              <div className="modal-content">
                <div className="modal-header">
                  <h4 className="modal-title"> {t("silver")} </h4>
                  <button
                    type="button"
                    className="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                  ></button>
                </div>
                <div className="modal-body">
                  <div className="row">
                    <p>
                      {t("silver-text")}
                    </p>
                    {/* <div className="text-center mt-4"><button style={{backgroundColor:'#68A4C4',width:150}} onClick={()=>this.GotoCompetion("silver")} name="submit" id="form-submit" type="submit" className="btn btn-md btn-black">Participation</button></div> */}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div
            id="bronzeAward"
            className="TradeSubscription_scroll modal fade align-middle"
            role="dialog"
          >
            <div className="modal-dialog modal-dialog-centered modal-lg">
              <div className="modal-content">
                <div className="modal-header">
                  <h4 className="modal-title">{t("bronze")}</h4>
                  <button
                    type="button"
                    className="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                  ></button>
                </div>
                <div className="modal-body">
                  <div className="row">
                    <p>
                     {t("bronze-text")}
                    </p>
                    {/* <div className="text-center mt-4"><button style={{backgroundColor:'#68A4C4',width:150}}  onClick={()=>this.GotoCompetion("bronze")} name="submit" id="form-submit" type="submit" className="btn btn-md btn-black">Participation</button></div> */}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </React.Fragment>

        <Footer></Footer>
      </React.Fragment>
    );
  }
})
