import React, { Component } from "react";
import Header from "containers/Header/Header";
import Footer from "components/footer";
import { Link, Redirect } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { DashBoardScreenPropsFromRedux } from "containers/Dashboard";
import StorageManagement from "utils/StorageManagement";
import { isEmpty } from "appredux/common/validationUtils";
import DataTable from "components/DataTable";
import ApiRequest from "utils/ApiRequest";
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import { TextField } from '@material-ui/core';
import 'react-tabs/style/react-tabs.css';
import { toast } from "react-toastify";
import MakeApiRequest from "utils/ApiRequest";

import Select from "react-select";
interface IProps { }
interface IState {
  goToAuth: boolean;
  goToUrl?: string;
  userName?: string;
  AppUser?: string;
  UserId: string,
  tabIndex: number,
  skill: string,
  exp: string,
  competitionname?: string,
  startdate?: string,
  enddate?: string,
  comstatus?: string,
  description?: string,
  type?: string,
  comBtn: boolean,
  comList:Array<any>,
  userComlist:Array<any>,
  parList:Array<any>,
  adminUser:Array<any>,
  currentRowData:any,
  comments:"",
  tempstatus:any,
  emailid:any,
  emailbody:any,
  subject:any
}



type Props = DashBoardScreenPropsFromRedux & IProps;
export default class DashBoardScreen extends Component<Props, IState> {
  _isMounted = false;
  constructor(props: Props) {
    super(props);
    this.state = {
      goToAuth: false,
      userName: '',
      AppUser: '',
      UserId: '',
      tabIndex: 0,
      skill: '',
      exp: '',
      competitionname: "",
      comstatus: "",
      description: "",
      type: "",
      startdate:"",
      enddate: "",
      comBtn: false,
      comList:[],
      parList:[],
      userComlist:[],
      adminUser:[],
      currentRowData:"",
      comments:"",
      tempstatus:"",
      emailid:"",
  emailbody:"",
  subject:""

    };
  }

  async componentDidMount() {
    this._isMounted = true;
    let userData = await StorageManagement.getUserData();
    if(userData)
    {
    this.setState({
      userName: userData ?.UserName!,
      AppUser: userData ?.AppUser!,
      UserId: userData ?.UserId!,
    });
    this.getAdminUserList();
    this.getParticpantList();
    this.getCompetionList()
    this.props.GetSkillList(this.state.UserId);
  }
  }

  componentWillUnmount() {
   // this.MakeApiRequest.abort()
  }

  componentDidUpdate(prevProps: Props) {
    if (!this.props.dashboard ?.skillsuccess && this.props.dashboard ?.skillerror != null) {
      if (prevProps.dashboard ?.skillerror != this.props.dashboard ?.skillerror) {
        this.ShowErrorMessage(this.props.dashboard.skillerror.ExceptionMessage.toString());
      }
    } else if (this.props.dashboard ?.skillsuccess) {
      if (prevProps.dashboard.skillsuccess != this.props.dashboard.skillsuccess) {
        this.ResetFormSkill();
        window.jQuery("#AddSkillsForm").hide();
        this.props.GetSkillList(this.state.UserId);
      }
    }
  }

  getAdminUserList = () => {
    MakeApiRequest.post("masters/any/users/list",{})
    .then(response => {
      
      setTimeout(() => this.setState({"adminUser":response.data.data}), 100);
      
    })
    .catch(errorresponse => {
     
    });
  }

  getParticpantList = () => {
    MakeApiRequest.post("masters/any/userparticipant/list",{})
    .then(response => {
      
      setTimeout(() => this.setState({"parList":response.data.data}), 100);
      let result = response ?.data ?.data ?.filter((x: any) => x.UserId === this.state.UserId || x.UserName == this.state.userName);
      setTimeout(() => this.setState({"userComlist":result}), 100);
    })
    .catch(errorresponse => {
     
    });
  }

  getCompetionList = () => {
    MakeApiRequest.post("masters/any/competition/list",{})
    .then(response => {

      
      
      setTimeout(() => this.setState({"comList":response.data.data}), 100);
      
    })
    .catch(errorresponse => {
     
    });
  }


  ShowErrorMessage = (errorMessage: string) => {
    toast.error(errorMessage, {
      autoClose: false,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: false,
      progress: false,
    });
  }


  AddSKill = (d: any) => {
    window.jQuery("#AddSkillsForm").show();
  }

  AddCompetion = (d: any) => {
    window.jQuery("#AddCompetitionForm").show();
  }

  keyPress = (event?: any, type?: string) => {
    event.persist();
    if (this.props ?.dashboard ?.skillisFormValid) {
      this.ValidateForm();
    }
  }


  ValidateForm = () => {
    this.props.ValidateSkillForm({
      Skills: this.state.skill,
      Exp: this.state.exp,

    });
  }




  textChange = (event: any, type: string) => {
    switch (type) {
      case "Skill":
        this.setState({ 'skill': event.target.value });
        break;
      case 'Experience':
        this.setState({ 'exp': event.target.value });
        break;
    }


  }

  comListCallBack = (rowData: any) =>{
      this.setState({"competitionname":rowData.competitionname,"startdate":rowData.startdate,"enddate":rowData.enddate
    ,"type":rowData.type,"description":rowData.description});
    this.setState({"currentRowData":rowData})
  }

  parListCallBack= (rowData: any) =>{
   
      this.setState({"currentRowData":rowData})
  }

  DownLoad= (rowData: any) =>{
    if(this.state.currentRowData != "")
    {

    }
  }

  comTextChange = (event: any, type: string) => {
    var demotext : any = {};
    demotext[type]=  event.target.value 
    this.setState(demotext);


  }

  commmentsTextChange= (event: any, type: string) => {
    var demotext : any = {};
    demotext[type]=  event.target.value 
    this.setState(demotext);


  }

  emailTextChange=(event: any, type: string) => {
    var demotext : any = {};
    demotext[type]=  event.target.value 
    this.setState(demotext);


  }

  ResetFormSkill = () => {
    this.setState({ skill: '', exp: '' })
  }

  GoToAuth = () => {

    this.props.SubmitSkillBtnClicked(true);
    this.ValidateForm();
    setTimeout(() => this.SubmitForm(), 0);
  }

  compBtnClick = () => {
    this.setState({ 'comBtn': true });
    if(this.state.competitionname  != ""&& this.state.startdate != null && this.state.description !="" && this.state.type != "")
       this.SubmitComForm()

  }

  commentBtnClick= () => {
    this.setState({ 'comBtn': true });
    if(this.state.comstatus  != ""&& this.state.comments != null )
       this.SubmitCommentsForm()

  }

  EditComForm = (event: any) => {
    window.jQuery("#AddCompetitionForm").show();


  }

  addcomments= (event: any) => {
    window.jQuery("#AddComments").show();
    this.setState({"comments" : this.state.currentRowData.comments,"comstatus":this.state.currentRowData.Status})

  }

  
  sendmail= () => {
    this.setState({comBtn:true})
  
      var payload={
        emailid:this.state.emailid,
        emailbody:this.state.emailbody,
        subject:this.state.subject
      }
      MakeApiRequest.post('masters/any/email/add', payload)
      .then(response => {
          if(response?.status)
          {
           // window.jQuery("#AddCompetitionForm").hide();
           // window.location.reload();
           window.location.reload(false);
            //location.reload();
          }
      })
      .catch(errorresponse => {
       
      });
   // }
  }
  DeleteComForm = () => {
    if(this.state.currentRowData != "")
    {
      MakeApiRequest.post('masters/any/competition/delete/'+ this.state.currentRowData["_id"], {})
      .then(response => {
          if(response?.status)
          {
            window.jQuery("#AddCompetitionForm").hide();
            window.location.reload(false);
            //location.reload();
          }
      })
      .catch(errorresponse => {
       
      });
    }
  }


  SubmitForm = () => {
    if (this.props.dashboard ?.skillisSubmitBtnClicked && this.props.dashboard ?.skillisFormValid) {
      this.props.SubmitSkill({
        Skills: this.state.skill,
        Exp: this.state.exp,
        UserId: this.state.UserId
      });
    }
  }

  SubmitCommentsForm= () => {
    debugger
    var payload ={
      Title: this.state.currentRowData["Title"],
      Date: this.state.currentRowData["Date"],
      Purpose: this.state.currentRowData["Purpose"],
      DocumentLink: this.state.currentRowData["DocumentLink"],
      CompetitionId: this.state.currentRowData["CompetitionId"],
      UserName: this.state.currentRowData["UserName"],
      UserId: this.state.currentRowData["UserId"],
      comments:this.state.comments,
      Status:this.state.tempstatus
    }
    if(this.state.currentRowData == "")
    {
     
    }
    else
    {
      
      MakeApiRequest.post('masters/any/userparticipant/edit/'+ this.state.currentRowData["_id"], payload)
      .then(response => {
          if(response?.status)
          {
            window.jQuery("#AddComments").hide();
            window.location.reload(false);
            //location.reload();
          }
      })
      .catch(errorresponse => {
       
      });
    }
   
  }

  SubmitComForm = () => {
    var payload ={
      competitionname: this.state.competitionname,
      type: this.state.type,
      status: "Active",
      startdate:this.state.startdate,
      enddate:this.state.enddate,
      description:this.state.description,
    }
    if(this.state.currentRowData == "")
    {
      MakeApiRequest.post('masters/any/competition/add', payload)
      .then(response => {
          if(response?.status)
          {
            window.jQuery("#AddCompetitionForm").hide();
            window.location.reload(false);
            //location.reload();
          }
      })
      .catch(errorresponse => {
       
      });
    }
    else
    {
      
      MakeApiRequest.post('masters/any/competition/edit/'+ this.state.currentRowData["_id"], payload)
      .then(response => {
          if(response?.status)
          {
            window.jQuery("#AddCompetitionForm").hide();
            window.location.reload(false);
            //location.reload();
          }
      })
      .catch(errorresponse => {
       
      });
    }
   
  }

   drowpDownChange = (event: any, type: string) => {
     debugger
   //console.log("type", type);
     switch (type) {
       case "comstatus":
         this.setState({ comstatus: event ,tempstatus: event["value"]});
         break;
     }
   };

  render() {

    if (this.state.goToAuth === true) {
      return (
        <Redirect
          to={`${process.env.PUBLIC_URL}/${this.state.goToUrl}`}
          push={true}
        />
      );
    }

    return (
      <React.Fragment>
        <Header authenticated={this.props.session.checked && this.props.session.authenticated}  ></Header>
        <React.Fragment>
          <ToastContainer
            position="top-center"
            hideProgressBar={false}
            autoClose={false}
            newestOnTop={true}
            closeOnClick={false}
            draggable={false}
            rtl={false}
          />
        </React.Fragment>


        <main id="main">
          <section className="breadcrumbs">
            <div className="container">
              <div className="d-flex justify-content-between align-items-center">
                <h2>       {this.state ?.AppUser === 'adminuser' ? " Admin Dashboard" : !isEmpty(this.state ?.userName) ? this.state ?.userName + ' - Dashboard' : ''}</h2>
                <ol>
                  <li>
                    {" "}
                    <Link to={`${process.env.PUBLIC_URL}/`}>Home</Link>
                  </li>
                  <li>Dashboard</li>
                </ol>
              </div>
            </div>
          </section>
          {
            this.state.AppUser === 'adminuser' ?
              <section
                className="contact"
                data-aos="fade-up"
                data-aos-easing="ease-in-out"
                data-aos-duration="500"
              >
                <div className="container">
                  <div>
                    <Tabs selectedIndex={this.state.tabIndex} onSelect={(tabIndex: any) => this.setState({ "tabIndex": tabIndex })}>
                      <TabList>
                        <Tab>Users</Tab>
                        <Tab>Participants </Tab>
                        <Tab>Competition</Tab>
                        <Tab>Email</Tab>
                      </TabList>

                      <TabPanel>
                        <DataTable
                          datasource={this.state.adminUser
                          }
                          isloading={this.props.dashboard.skilllistloading}
                          coldefs={[
                            {
                              title: "UserName",
                              field: "UserName",
                              sorting: true,
                            },
                            {
                              title: "FirstName",
                              field: "FirstName",
                              sorting: true,
                            },
                            {
                              title: "LastName",
                              field: "LastName",
                              sorting: true,
                            },
                            {
                              title: "EmailId",
                              field: "EmailId",
                              sorting: true,
                            },
                            {
                              title: "Phone Number",
                              field: "PhoneNumber",
                            },
                          ]}
                          options={{
                            search: true,
                            toolbar: true,
                            paging: true,
                            header: true,
                            exportButton: true,
                            pageSize: 10,
                            maxBodyHeight: 500,
                            pageSizeOptions: [10, 30, 50, 100],
                            actionsColumnIndex: -1,
                          }}
                        ></DataTable>
                      </TabPanel>
                      <TabPanel>
                        <DataTable
                            datasource={this.state.parList
                            }
                          
                          title=''
                          onRowClickCallback={this.parListCallBack}
                  
                          isloading={this.props.dashboard.skilllistloading}
                          coldefs={[
                            {
                              title: "User Name",
                              field: "UserName",
                              sorting: true,
                            },
                            {
                              title: "Title",
                              field: "Title",
                              sorting: true,
                            },
                            {
                              title: "Date",
                              field: "Date",
                              sorting: true,
                            },
                            {
                              title: "Purpose",
                              field: "Purpose",
                              sorting: true,
                            },
                            {
                              title: "Status",
                              field: "Status",
                              sorting: true,
                            },
                            {
                              title: "",
                              field: "",
                              cellStyle: {
                                width: '10%',
                                maxWidth: 40
                              },
                              headerStyle: {
                                width:'10%',
                                maxWidth: 40
                              },
                              render: (rowData: any) => (
                                <React.Fragment>
                                  {
                                     <a href="javascript:void(0)" onClick={this.addcomments} >{"Comments"}</a>
                                   
                                  }
                                </React.Fragment>
                               
                              ),
                            },
                            {
                              title: "",
                              field: "DocumentLink",
                              cellStyle: {
                                width: '10%',
                                maxWidth: 40
                              },
                              headerStyle: {
                                width:'10%',
                                maxWidth: 40
                              },
                              render: (rowData: any) => (
                               
                                <React.Fragment>
                                  {
                                     <a href={rowData.DocumentLink} download >{"Download"}</a>
                                   
                                  }
                                </React.Fragment>
                               
                              ),
                            },
                           
                          ]}
                          options={{
                            search: true,
                            toolbar: true,
                            paging: true,
                            header: true,
                            maxBodyHeight: 500,
                            pageSize: 10,
                            pageSizeOptions: [10, 30, 50, 100],
                            actionsColumnIndex: -1,
                            exportButton: true
                          }}
                        ></DataTable>

                      </TabPanel>
                      <TabPanel>
                        <DataTable
                           datasource={this.state.comList
                           }
                          
                          title=''
                          onRowClickCallback={this.comListCallBack}
                          actions={[
                            {
                              icon: 'add',
                              tooltip: 'Add Competiton',
                              isFreeAction: true,
                              onClick: (event: any) => { this.AddCompetion(event) }
                            }
                          ]}
                          isloading={this.props.dashboard.skilllistloading}
                          coldefs={[
                            {
                              title: "Competition Name",
                              field: "competitionname",
                              sorting: true,
                            },
                            {
                              title: "Start Date",
                              field: "startdate",
                              sorting: true,
                            },
                            {
                              title: "End Date",
                              field: "enddate",
                              sorting: true,
                            },
                          
                            {
                              title: "",
                              field: "",
                              cellStyle: {
                                width: '5%',
                                maxWidth: 20
                              },
                              headerStyle: {
                                width:'5%',
                                maxWidth: 20
                              },
                              render: (rowData: any) => (
                               
                                <React.Fragment>
                                  {
                                     <a href="javascript:void(0)" onClick={(rowData) => this.EditComForm(rowData) } >{"Edit"}</a>
                                   
                                  }
                                </React.Fragment>
                               
                              ),
                            },
                            {
                              title: "",
                              field: "",
                              cellStyle: {
                                width: '5%',
                                maxWidth: 20
                              },
                              headerStyle: {
                                width:'5%',
                                maxWidth: 20
                              },
                              render: (rowData: any) => (
                                <React.Fragment>
                                  {
                                     <a href="javascript:void(0)" onClick={this.DeleteComForm} >{"Delete"}</a>
                                   
                                  }
                                </React.Fragment>
                               
                              ),
                            }
                          ]}
                          options={{
                            search: true,
                            toolbar: true,
                            paging: true,
                            header: true,
                            maxBodyHeight: 500,
                            pageSize: 10,
                            pageSizeOptions: [10, 30, 50, 100],
                            actionsColumnIndex: -1,
                            exportButton: true
                          }}
                        ></DataTable>

                      </TabPanel>
                      <TabPanel>
                      <div className="row">
                    <div className="col-lg-12">
                      <div
                        role="form"
                        style={{ boxShadow: 'none' }}
                        className="php-email-form"
                      >
                        <div className="form-group mt-3 mb-3">
                        <div className="form-group mt-3 mb-3">
                          <input
                            type="text"
                            className="form-control"
                            name="emailsubject"
                            id="subject"
                            required={true} placeholder="Email Subject" onChange={(text) => this.emailTextChange(text, 'subject')} value={this.state.subject} onKeyUp={(event) => this.keyPress(event, 'UserName')}
                          />
                          <div className="invalid-feedback ">{this.state.comBtn && this.state.subject == "" ? "Subject Required" : ""}</div>
                        </div>
                        </div>
                        <div className="form-group mt-3 mb-3">
                        <input
                            type="text"
                            className="form-control"
                            name="to"
                            id="subject"
                            required={true} placeholder="To Email" onChange={(text) => this.emailTextChange(text, 'emailid')} value={this.state.emailid} onKeyUp={(event) => this.keyPress(event, 'UserName')}
                          />
                          <div className="invalid-feedback ">{this.state.comBtn && this.state.emailid == "" ? "Emails Required" : ""}</div>
                        </div>
                        <div className="form-group mt-3 mb-3">
                        <textarea
                        className="form-control"
                        name="body"
                        rows={5}
                        data-rule="required"
                        data-msg="Please write something for us"
                        placeholder="Email body Content"
                        onChange={(text) => this.emailTextChange(text, 'emailbody')} value={this.state.emailbody} onKeyUp={(event) => this.keyPress(event, 'UserName')}
                      ></textarea>
                        {/* <input
                            type="text"
                            className="form-control"
                            name="body"
                            id="subject"
                            required={true} placeholder="Email body Content" onChange={(text) => this.emailTextChange(text, 'emailbody')} value={this.state.emailbody} onKeyUp={(event) => this.keyPress(event, 'UserName')}
                          /> */}
                          <div className="invalid-feedback ">{this.state.comBtn && this.state.emailbody == "" ? "Email Body is Required" : ""}</div>
                        </div>
                        <div className="text-center">
                          <button type="submit" className="btn btn-md btn-black" onClick={this.sendmail}  >Send Mail</button>
                        </div>
                      </div>
                    </div>

                  </div>

                      </TabPanel>
                     
                    </Tabs>



                  </div>
                </div>
              </section>

              :

              <section
                className="contact"
                data-aos="fade-up"
                data-aos-easing="ease-in-out"
                data-aos-duration="500"
              >
                <div className="container">
                  <div>
                    <Tabs selectedIndex={this.state.tabIndex} onSelect={(tabIndex: any) => this.setState({"tabIndex": tabIndex })}>
                      <TabList>
                        <Tab>Dashboard</Tab>
                        <Tab>Add Skills</Tab>
                      </TabList>
                      <TabPanel>
                        <DataTable
                          datasource={this.state.userComlist
                          }
                          
                          title=''
                          onRowClickCallback={this.parListCallBack}
                  
                          isloading={this.props.dashboard.skilllistloading}
                          coldefs={[
                            {
                              title: "User Name",
                              field: "UserName",
                              sorting: true,
                            },
                            {
                              title: "Title",
                              field: "Title",
                              sorting: true,
                            },
                            {
                              title: "Date",
                              field: "Date",
                              sorting: true,
                            },
                            {
                              title: "Purpose",
                              field: "Purpose",
                              sorting: true,
                            },
                            {
                              title: "Status",
                              field: "Status",
                              sorting: true,
                            },
                            {
                              title: "",
                              field: "DocumentLink",
                              cellStyle: {
                                width: '7%',
                                maxWidth: 40
                              },
                              headerStyle: {
                                width:'7%',
                                maxWidth: 40
                              },
                              render: (rowData: any) => (
                               
                                <React.Fragment>
                                  {
                                     <a href={rowData.DocumentLink} download >{"Download"}</a>
                                   
                                  }
                                </React.Fragment>
                               
                              ),
                            }
                           
                          ]}
                          options={{
                            search: true,
                            toolbar: true,
                            paging: true,
                            header: true,
                            maxBodyHeight: 500,
                            pageSize: 10,
                            pageSizeOptions: [10, 30, 50, 100],
                            actionsColumnIndex: -1,
                            exportButton: true
                          }}
                        ></DataTable>

                      </TabPanel>
                     
                      <TabPanel>
                        <DataTable
                          datasource={
                            this.props.dashboard ?.data               
        }
                          title=''
                          actions={[
                            {
                              icon: 'add',
                              tooltip: 'Add Skill',
                              isFreeAction: true,
                              onClick: (event: any) => { this.AddSKill(event) }
                            }
                          ]}
                          isloading={this.props.dashboard.skilllistloading}
                          coldefs={[
                            {
                              title: "S No",
                              field: "sno",
                              sorting: true,
                            },
                            {
                              title: "Skill",
                              field: "Skills",
                              sorting: true,
                            },
                            {
                              title: "Experience",
                              field: "Exp",
                              sorting: true,
                            },
                          ]}
                          options={{
                            search: true,
                            toolbar: true,
                            paging: true,
                            header: true,
                            maxBodyHeight: 500,
                            pageSize: 10,
                            pageSizeOptions: [10, 30, 50, 100],
                            actionsColumnIndex: -1,
                            exportButton: true
                          }}
                        ></DataTable>

                      </TabPanel>
                    </Tabs>


                  </div>
                </div>
              </section>

          }
          <div
            id="AddSkillsForm"
            className="contact modal align-middle"
            role="dialog"
          >
            <div className="modal-dialog modal-dialog-centered modal-lg">
              <div className="modal-content">
                <div className="modal-header">
                  <h4 className="modal-title">Add Skills</h4>
                  <button
                    type="button"
                    className="btn-close"
                    onClick={() =>
                      window.jQuery("#AddSkillsForm").hide()
                    }
                    data-bs-dismiss="modal"
                    aria-label="Close"
                  ></button>
                </div>
                <div className="modal-body">
                  <div className="row">
                    <div className="col-lg-12">
                      <div
                        role="form"
                        style={{ boxShadow: 'none' }}
                        className="php-email-form"
                      >
                        <div className="form-group mt-3 mb-3">
                          <input
                            type="text"
                            className="form-control"
                            name="username"
                            id="subject"
                            required={true} placeholder="Enter your Skill set" onChange={(text) => this.textChange(text, 'Skill')} value={this.state.skill} onKeyUp={(event) => this.keyPress(event, 'UserName')}
                          />
                          <div className="invalid-feedback ">{this.props.dashboard ?.validationSkillsErrors ?.Skills}</div>
                        </div>
                        <div className="form-group mt-3 mb-3">
                          <input
                            type="text"
                            className="form-control"
                            name="username"
                            id="subject"
                            required={true} placeholder="Enter your Total Experience" onChange={(text) => this.textChange(text, 'Experience')} value={this.state.exp} onKeyUp={(event) => this.keyPress(event, 'UserName')}
                          />
                          <div className="invalid-feedback ">{this.props.dashboard ?.validationSkillsErrors ?.Exp}</div>
                        </div>
                        <div className="text-center">
                          <button type="submit" className="btn btn-md btn-black" onClick={this.GoToAuth}  >Add</button>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>
          <div
            id="AddComments"
            className="contact modal align-middle"
            role="dialog"
          >
            <div className="modal-dialog modal-dialog-centered modal-lg">
              <div className="modal-content">
                <div className="modal-header">
                  <h4 className="modal-title">Add Comments</h4>
                  <button
                    type="button"
                    className="btn-close"
                    onClick={() =>
                      window.jQuery("#AddComments").hide()
                    }
                    data-bs-dismiss="modal"
                    aria-label="Close"
                  ></button>
                </div>
                <div className="modal-body">
                  <div className="row">
                    <div className="col-lg-12">
                      <div
                        role="form"
                        style={{ boxShadow: 'none' }}
                        className="php-email-form"
                      >
                        <div className="form-group mt-3 mb-3">
                        <div className="form-group mt-3 mb-3">
                          <input
                            type="text"
                            className="form-control"
                            name="Comments"
                            id="subject"
                            required={true} placeholder="Enter your Comments" onChange={(text) => this.commmentsTextChange(text, 'comments')} value={this.state.comments} onKeyUp={(event) => this.keyPress(event, 'UserName')}
                          />
                          <div className="invalid-feedback ">{this.state.comBtn && this.state.comments == "" ? "Comments Required" : ""}</div>
                        </div>
                        </div>
                        <div className="form-group mt-3 mb-3">
                        <Select
                             onKeyPress={(e: any) => this.keyPress(e)}
                              options={[{label:'Approved',value:"Approved"},{label:'Hold',value:"Hold"},{label:'Rejected',value:"Rejected"}]}
                              onChange={(e: any) =>
                                this.drowpDownChange(e, "comstatus")
                              }
                              value={this.state.comstatus}
                              arrowClosed={<span className="arrow-closed" />}
                              arrowOpen={<span className="arrow-open" />}
                              placeholder="Select an option"
                            />
                          <div className="invalid-feedback ">{this.state.comstatus && this.state.comstatus == "" ? "Status Required" : ""}</div>
                        </div>
                        <div className="text-center">
                          <button type="submit" className="btn btn-md btn-black" onClick={this.commentBtnClick}  >Add</button>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>
          <div
            id="AddCompetitionForm"
            className="contact modal align-middle"
            role="dialog"
          >
            <div className="modal-dialog modal-dialog-centered modal-lg">
              <div className="modal-content">
                <div className="modal-header">
                  <h4 className="modal-title">Add Competition</h4>
                  <button
                    type="button"
                    className="btn-close"
                    onClick={() =>
                      window.jQuery("#AddCompetitionForm").hide()
                    }
                    data-bs-dismiss="modal"
                    aria-label="Close"
                  ></button>
                </div>
                <div className="modal-body">
                  <div className="row">
                    <div className="col-lg-12">
                      <div
                        role="form"
                        style={{ boxShadow: 'none' }}
                        className="php-email-form"
                      >
                        <div className="form-group mt-3 mb-3">
                          <input
                            type="text"
                            className="form-control"
                            name="Competition Name"
                            id="subject"
                            required={true} placeholder="Enter your Competition Name" onChange={(text) => this.comTextChange(text, 'competitionname')} value={this.state.competitionname} onKeyUp={(event) => this.keyPress(event, 'UserName')}
                          />
                          <div className="invalid-feedback ">{this.state.comBtn && this.state.competitionname == "" ? "Competition Name Required" : ""}</div>
                        </div>
                        <div className="form-group mt-3 mb-3">
                          <input
                            type="text"
                            className="form-control"
                            name="Type"
                            id="subject"
                            required={true} placeholder="Enter the Type" onChange={(text) => this.comTextChange(text, 'type')} value={this.state.type} onKeyUp={(event) => this.keyPress(event, 'UserName')}
                          />
                          <div className="invalid-feedback ">{this.state.comBtn && this.state.type == "" ? "Type Required" : ""}</div>
                        </div>
                        <div className="form-group mt-3 mb-3">
                          <TextField
                            id="date"
                            label="Start Date"
                            type="datetime-local"
                            required={true}
                            value={this.state.startdate}
                            placeholder="dd"
                            defaultValue={new Date().toISOString()}
                            onChange={(text) => this.comTextChange(text, 'startdate')}
                          />
                          <div className="invalid-feedback ">{this.state.comBtn && this.state.startdate == null ? "Start Date Required" : ""}</div>
                        </div>
                        <div className="form-group mt-3 mb-3">
                          <TextField
                            id="date"
                            label="End Date"
                            type="datetime-local"
                            value={this.state.enddate}
                            placeholder="dd"
                            defaultValue={new Date().toISOString()}
                            onChange={(text) => this.comTextChange(text, 'enddate')}
                          />
                        </div>
                        <div className="form-group mt-3 mb-3">
                          <input
                            type="text"
                            className="form-control"
                            name="Description"
                            id="subject"
                            required={true} placeholder="Enter the Description" onChange={(text) => this.comTextChange(text, 'description')} value={this.state.description} onKeyUp={(event) => this.keyPress(event, 'UserName')}
                          />
                          <div className="invalid-feedback ">{this.state.comBtn && this.state.description == "" ? "Description Required" : ""}</div>
                        </div>
                        <div className="text-center">
                          <button type="submit" className="btn btn-md btn-black" onClick={this.compBtnClick}  >Add</button>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>


        </main>
        <React.Fragment>

        </React.Fragment>


        <Footer></Footer>
      </React.Fragment>
    );
  }
}
