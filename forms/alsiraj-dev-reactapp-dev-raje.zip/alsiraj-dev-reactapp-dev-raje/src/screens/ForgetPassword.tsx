import React, { Component } from "react";
import Header from "containers/Header/Header";
import Footer from "components/footer";
import { Link, Redirect } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { ForgetPasswordScreenPropsFromRedux } from "containers/ForgetPassword";

interface IProps {

}
interface IState {
    goToAuth: boolean,
    goToUrl?: string,
   
}

type Props =ForgetPasswordScreenPropsFromRedux & IProps;
export default class ForgetPasswordScreen extends Component<Props, IState>{
    constructor(props: Props) {
        super(props);
        this.state = {
            goToAuth: false,
        };
    }

    async componentDidMount() {
    }

    componentDidUpdate(prevProps: Props) {
        //screenWidth = Dimensions.get("window");
        
    }

  




    render() {

        if (this.state.goToAuth === true) {
            return <Redirect to={`${process.env.PUBLIC_URL}/${this.state.goToUrl}`} push={true} />
        }
        return (
          <React.Fragment>
            <Header
             
            ></Header>
            <React.Fragment>
              <ToastContainer
                position="top-center"
                hideProgressBar={false}
                autoClose={false}
                newestOnTop={true}
                closeOnClick={false}
                draggable={false}
                rtl={false}
              />
            </React.Fragment>
            <main id="main">
              <section className="breadcrumbs">
                <div className="container">
                  <div className="d-flex justify-content-between align-items-center">
                    <h2> Reset Password</h2>
                    <ol>
                      <li>
                        {" "}
                        <Link to={`${process.env.PUBLIC_URL}/`}>Home</Link>
                      </li>
                      <li>Reset Password</li>
                    </ol>
                  </div>
                </div>
              </section>
              <section className="about" data-aos="fade-up">
                <div className="container">
                  <div className="row">
                  <section
            className="contact"
            data-aos="fade-up"
            data-aos-easing="ease-in-out"
            data-aos-duration="500"
          >
            <div className="container">
              <div className="row justify-content-center">
                <div className="col-lg-4 center-block">
                    <div className="info-box">
                <i className="bx bx-user"></i>
                <h3>
                    Login
                </h3>
                  <div
                    role="form"
                    style={{boxShadow:'none'}}
                    className="php-email-form"
                  >
                    <div className="row">
                      <div className="col-md-12 form-group">
                        <input
                          type="email"
                          name="name"
                          className="form-control"
                          id="name"
                          placeholder="Email"
                        />
                        <div className="validate"></div>
                      </div>
                    </div>
                    <div className="form-group mt-3">
                      <input
                        type="text"
                        className="form-control"
                        name="password"
                        id="password"
                        placeholder="Password"
                      />
                      <div className="validate"></div>
                    </div>
                    <div className="mb-3">
                      <div className="loading">Loading</div>
                      <div className="error-message"></div>
                      <div className="sent-message">
                        Your message has been sent. Thank you!
                      </div>
                    </div>
                    <div className="text-center">
                      <button type="submit">Login</button>
                    </div>
                  </div>
                  <div className="row">
                  <Link className="col-6" to={`${process.env.PUBLIC_URL}/signup`}>New Customer?</Link>
                  <Link className="col-6" to={`${process.env.PUBLIC_URL}/reset`}>Forgot password?</Link>
                  </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
       
                  </div>
                </div>
              </section>
              <section className="testimonials"></section>
            </main>

            <Footer></Footer>
          </React.Fragment>
        );
    }
}