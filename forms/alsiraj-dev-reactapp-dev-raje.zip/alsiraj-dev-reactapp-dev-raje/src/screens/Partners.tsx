import React, { Component } from "react";
import Header from "containers/Header/Header";
import Footer from "components/footer";
import { Link, Redirect } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { PartnersScreenPropsFromRedux } from "containers/Partners";
import { useTranslation,withTranslation } from 'react-i18next';

interface IProps { t?:any}
interface IState {
  goToAuth: boolean;
  goToUrl?: string;
}

type Props = PartnersScreenPropsFromRedux & IProps;
export default withTranslation('default') (class PartnersScreen extends Component<Props, IState> {
  constructor(props: Props) {
    super(props);
    this.state = {
      goToAuth: false,
    };
  }

  async componentDidMount() {}

  componentDidUpdate(prevProps: Props) {}

  render() {
    const {t} = this.props;
    if (this.state.goToAuth === true) {
      return (
        <Redirect
          to={`${process.env.PUBLIC_URL}/${this.state.goToUrl}`}
          push={true}
        />
      );
    }
    return (
      <React.Fragment>
        <Header
          authenticated={
            this.props.session.checked && this.props.session.authenticated
          }
        ></Header>
        <React.Fragment>
          <ToastContainer
            position="top-center"
            hideProgressBar={false}
            autoClose={false}
            newestOnTop={true}
            closeOnClick={false}
            draggable={false}
            rtl={false}
          />
        </React.Fragment>
        <main id="main">
          <section className="breadcrumbs">
            <div className="container">
              <div className="d-flex justify-content-between align-items-center">
                <h2>{t("menu-partners")}</h2>
                <ol>
                  <li>
                    {" "}
                    <Link to={`${process.env.PUBLIC_URL}/`}>{t("menu-home")}</Link>
                  </li>
                  <li>{t("menu-partners")}</li>
                </ol>
              </div>
            </div>
          </section>

          <section className="services">
            <div className="container">
              <div className="row">
                <div className="col-lg-12 pt-6 pt-lg-2">
                  <p>
                  {t("partner")}
                  </p>
                </div>
              </div>
              <div className="row">
                <div
                  className="col-md-6 col-lg-3 d-flex align-items-stretch"
                  data-aos="fade-up"
                  onClick={()=> window.open("http://essbc.ae/", "_blank")}
                >
                  <div className="icon-box icon-box-pink ">
                    <img
                     
                      src={`${process.env.PUBLIC_URL}/img/partners/essbc.png`}
                      style={{ marginTop: 78}}
                      alt="..."
                      className=" text-center rounded mx-auto d-block"
                    ></img>
                  </div>
                </div>

                <div
                  className="col-md-6 col-lg-3 d-flex align-items-stretch"
                  data-aos="fade-up"
                  data-aos-delay="100"
                >
                  <div className="icon-box icon-box-cyan">
                    <img
                      
                      src={`${process.env.PUBLIC_URL}/img/partners/kadi.png`}
                      style={{ minHeight: 92, minWidth: 260 }}
                      alt="..."
                      className="text-center rounded mx-auto d-block"
                    ></img>
                  </div>
                </div>

                <div
                  className="col-md-6 col-lg-3 d-flex align-items-stretch"
                  data-aos="fade-up"
                  data-aos-delay="200"
                >
                  <div className="icon-box icon-box-green">
                    <img
                      src={`${process.env.PUBLIC_URL}/img/partners/estobar.png`}
                      style={{ minHeight: 92,marginTop: 82 }}
                      alt="..."
                      className=" text-center rounded mx-auto d-block"
                    ></img>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="service-details"></section>
        </main>

        <Footer></Footer>
      </React.Fragment>
    );
  }
})
