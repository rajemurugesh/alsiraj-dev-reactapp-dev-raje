import React, { Component } from "react";
import Header from "containers/Header/Header";
import Footer from "components/footer";
import { Link, Redirect } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { SignupScreenPropsFromRedux } from "containers/Signup";
import InputMask from 'react-input-mask';
import { toast } from "react-toastify";
import Select from "react-select";
import { CompetionScreenPropsFromRedux } from "containers/Competion";
import StorageManagement from "utils/StorageManagement";
interface IProps {
  navigation: any;
}
interface IState {
  goToAuth: boolean,
  goToUrl?: string,
  title: string,
  date:any,
  purpose:any,
  document:any,
   userId:any,
   UserName:any
}

type Props = CompetionScreenPropsFromRedux & IProps;
export default class CompetionScreen extends Component<Props, IState>{
    constructor(props: Props) {
        super(props);
        this.state = {
          goToAuth: false,
          title: '',
          date:'',
          purpose:'',
          document:'',
          userId:'',
          UserName:""
        };
    }

    componentDidUpdate(prevProps: Props) {
      if (this.props.competition.loading != null) {
        if (prevProps.competition.loading != this.props.competition.loading) {
          this.ToggleLoadingScreen();
        }
      }
  
      if (!this.props.competition?.success && this.props.competition?.error != null) {
        if (prevProps.competition?.error != this.props.competition?.error) {
          this.ShowErrorMessage(this.props.competition.error.ExceptionMessage.toString());
        }
      } else if (this.props.competition?.success) {
        if (prevProps.competition.success != this.props.competition.success) {
          this.ShowSuccessMessage();
        }
      }


      if (!this.props.competition?.fileSuccess && this.props.competition?.fileError != null) {
        if (prevProps.competition?.fileError != this.props.competition?.error) {
          this.ShowErrorMessage(this.props.competition.fileError.ExceptionMessage.toString());
        }
      } else if (this.props.competition?.fileSuccess) {
        if (prevProps.competition.url != this.props.competition.url) {
              
          this.setState({document:this.props.competition?.url?.filePath!})
        }
      }
  
    
    }
  
    async componentDidMount() {
      let userData = await StorageManagement.getUserData();
      this.setState({userId: userData ?.UserId!,UserName:userData ?.UserName!})
    }
  
  

    handleKeyDown=(event: any) => {
     console.log(event);
      if ( event.key === 'Enter')
      {
        event.preventDefault();
        this.GoToAuth()
      }
    }
    ShowErrorMessage = (errorMessage: string) => {
      toast.error(errorMessage, {
        autoClose: false,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: false,
        progress: false,
      });
    }
    ShowSuccessMessage = async () => {
      // toast.success("You have been successfully competitioned!!!", {
      //   autoClose: false,
      //   hideProgressBar: true,
      //   closeOnClick: true,
      //   pauseOnHover: true,
      //   draggable: false,
      //   progress: false,
      // });
      sessionStorage.setItem("CompetitionType", "");
      setTimeout(()=>{
        this.setState({
          goToAuth: true,
          goToUrl: 'dashboard'
          });
    },1000);
      this.props.CompetitionSubmitBtnClicked(false);
    }
  
    ToggleLoadingScreen = () => {
      if (this.props.competition.loading) {
        window.jQuery('#dataloader').show();
      } else {
        window.jQuery('#dataloader').hide();
      }
    }
  
  
    GoToAuth = () => {
      this.props.CompetitionResetForm();
      this.props.CompetitionSubmitBtnClicked(true);
      this.ValidateForm();
      setTimeout(() => this.SubmitForm(), 0);
    }
  
  
    SubmitForm = () => {
      if (this.props.competition?.isSubmitBtnClicked && this.props.competition?.isFormValid) {
        //this.Loader(true);
         
        this.props.SubmitCompetitionation({
         Title:this.state.title,
         Date:this.state.date,
         Purpose:this.state.purpose,
         DocumentLink:this.state.document,
         CompetitionId:sessionStorage?.getItem("CompetitionType")?.toString(),
         UserId:this.state.userId,
         UserName:this.state.UserName,
         Status:"New"
        });
      }
    }
  
    ValidateForm = () => {
      this.props.CompetitionValidateForm({
        Title:this.state.title,
         Date:this.state.date,
         Purpose:this.state.purpose,
         DocumentLink:this.state.document,
      });
    }
  
    keyPress = (event?: any,type?:string) => {
      event.persist();
      if (this.props?.competition?.isSubmitBtnClicked) {
        this.ValidateForm();
      }
    }
    textChange = (event: any, type: string) => {
      switch (type) {
        case "Title":
          this.setState({ 'title': event.target.value });
          break;
        case 'Date':
          this.setState({ 'date': event.target.value });
          break;
        case 'Purpose':
          this.setState({ 'purpose': event.target.value });
          break;
          case 'DocumentLink':
            this.setState({ 'document': event.target.value });
            break;
      }
  
  
    }



    importFile=(e:any)=>{
      let file = e.target.files[0];
      this.props.fileUpload(file);
    }

  




    render() {

        if (this.state.goToAuth === true) {
            return <Redirect to={`${process.env.PUBLIC_URL}/${this.state.goToUrl}`} push={true} />
        }
        return (
          <React.Fragment>
            <Header
             
            ></Header>
            <React.Fragment>
              <ToastContainer
                position="top-center"
                hideProgressBar={false}
                autoClose={false}
                newestOnTop={true}
                closeOnClick={false}
                draggable={false}
                rtl={false}
              />
            </React.Fragment>
            <main id="main">
              <section className="breadcrumbs">
                <div className="container">
                  <div className="d-flex justify-content-between align-items-center">
                    <h2>competition </h2>
                    <ol>
                      <li>
                        {" "}
                        <Link to={`${process.env.PUBLIC_URL}/`}>Home</Link>
                      </li>
                      <li> competition </li>
                    </ol>
                  </div>
                </div>
              </section>
              <section className="about" data-aos="fade-up">
                <div className="container">
                  <div className="row">
                  <section
            className="contact"
            data-aos="fade-up"
            data-aos-easing="ease-in-out"
            data-aos-duration="500"
          >
            <div className="container">
              <div className="row justify-content-center">
                <div className="col-lg-6 center-block">
                    <div className="info-box">
                <i className="bx bx-award"></i>
                <h3>
                Competition 
                </h3>
                <div className="col-lg-12">
                  <div
                    role="form"
                    style={{boxShadow:'none'}}
                    className="php-email-form"
                  >
                      <div className="form-group mt-3 mb-3">
                      <input
                        type="text"
                        className="form-control"
                        name="username"
                        id="subject"
                        onKeyPress={(e:any)=>this.handleKeyDown(e)}
                        required={true} placeholder="Title" onChange={(text) => this.textChange(text, 'Title')} value={this.state.title} onKeyUp={(event) => this.keyPress(event, 'Title')}
                      />
                      <div className="invalid-feedback ">{this.props.competition?.validationErrors?.Title}</div>
                    </div>
                  
                      <div className="form-group mt-3 mb-3">
                        <input
                          type="date"
                          onKeyUp={(e: any) => this.keyPress(e)}
                          onChange={(text) =>
                            this.textChange(text, "Date")
                          }
                          onKeyPress={(e:any)=>this.handleKeyDown(e)}
                          value={this.state.date}
                          name="name"
                          className="form-control"
                          id="name"
                          placeholder="Date"
                        />
                        <div className="invalid-feedback ">{this.props.competition?.validationErrors?.Date}</div>
                      </div>
                      <div className="form-group mt-3 mb-3">
                        <input
                          type="text"
                          onKeyPress={(e:any)=>this.handleKeyDown(e)}
                          onKeyUp={(e: any) => this.keyPress(e)}
                              onChange={(text) =>
                                this.textChange(text, "Purpose")
                              }
                              value={this.state.purpose}
                          className="form-control"
                          name="email"
                          id="email"
                          placeholder="Purpose"
                        />
                        <div className="invalid-feedback ">{this.props.competition?.validationErrors?.Purpose}</div>
                      </div>
                    <div className="form-group mt-3">
                    <input type="file" className="form-control"  onChange={(e)=>this.importFile(e)} id="customFile"></input>
                      <div className="invalid-feedback ">{this.props.competition?.validationErrors?.DocumentLink}</div>
                    </div>
                    
                    <div className="text-center mt-3">
                      <button type="submit" onClick={this.GoToAuth} >Submit</button>
                    </div>
                  </div>
                </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
       
                  </div>
                </div>
              </section>
              <section className="testimonials"></section>
            </main>

            <Footer></Footer>
          </React.Fragment>
        );
    }
}