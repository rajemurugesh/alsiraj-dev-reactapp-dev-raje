import React, { Component } from "react";
import Header from "containers/Header/Header";
import Footer from "components/footer";
import { Link, Redirect } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { LoginScreenPropsFromRedux } from "containers/Login";
import { toast } from "react-toastify";
import StorageManagement from "utils/StorageManagement";
import SocialButton from "components/SocialLogin/SocialButton";

interface IProps {

}
interface IState {
  emailAddress: string,
  password: string,
  goToAuth: boolean,
  goToUrl?: string,
  comId?:string
   
}

type Props = LoginScreenPropsFromRedux & IProps;

export default class LoginScreen extends Component<Props, IState>{
    constructor(props: Props) {
        super(props);
        this.state = {
            emailAddress: "",
            password: "",
            goToAuth: false,
            comId:""
        };
    }

     componentDidMount() {
       this.setState({comId:sessionStorage?.getItem("CompetitionType")?.toString()})
    }

    componentDidUpdate( prevProps: Props ){
  
      if (!this.props.register?.success && this.props.register?.error != null) {
        if (prevProps.register?.error != this.props.register?.error) {
          this.ShowErrorMessage(this.props.register.error.ExceptionMessage.toString());
        }
      } else if (this.props.register?.success) {
        if (prevProps.register.success != this.props.register.success) {
          this.SocialShowSuccessMessage();
        }
      }
      if ( !this.props.login.success && this.props.login.error != null ){
          if ( prevProps.login.error != this.props.login.error ) {
              this.ShowErrorMessage(this.props.login.error.ExceptionMessage.toString());            
          }            
      }else if ( this.props.login.success ){
          if ( prevProps.login.success != this.props.login.success ) {
              this.ShowSuccessMessage();            
          }            
      }        
  }

  ShowErrorMessage = (errorMessage: string) => {
      toast.error(errorMessage, {
        autoClose: false,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: false,
        progress: false,
      });
    }
  ShowSuccessMessage = async () => {      
    // toast.success("Logged In successfully!!!", {
    //   autoClose: false,
    //   hideProgressBar: true,
    //   closeOnClick: true,
    //   pauseOnHover: true,
    //   draggable: false,
    //   progress: false,
    // });
        const items = {
            "AccessToken": this.props.login.success?.data?.token!,
            "RefreshToken": this.props.login.success?.data?.refreshtoken!,
            "UserName": this.props.login.success?.data?.data?.UserName!,
            "AppUser": this.props.login.success?.data?.data?.AppUser!,
            "UserId": this.props.login.success?.data?.data?._id!,
        };   
          await StorageManagement.saveUserSession(items);
          setTimeout(()=>{
            this.setState({
              goToAuth: true,
              goToUrl: ''//this.state.comId == undefined||this.state.comId == ""? 'dashboard' : 'participation?type=' + this.state.comId
              });
        },1000);
          this.props.SubmitloginBtnClicked(false);
  }


  SocialShowSuccessMessage = async () => {
    // toast.success("Logged In successfully!!!", {
    //   autoClose: false,
    //   hideProgressBar: true,
    //   closeOnClick: true,
    //   pauseOnHover: true,
    //   draggable: false,
    //   progress: false,
    // });

    const items = {
      "AccessToken": this.props.login.success?.data?.token!,
      "RefreshToken": this.props.login.success?.data?.refreshtoken!,
      "AppUser": this.props.login.success?.data?.data?.AppUser!,
      "UserId": this.props.login.success?.data?.data?._id!,
  };   
    await StorageManagement.saveUserSession(items);
  
    setTimeout(()=>{
      this.setState({
        goToAuth: true,
        goToUrl: '',//this.state.comId == undefined  || this.state.comId == ""? 'dashboard' : 'participation?type=' + this.state.comId
        });
       
  },1000);
    this.props.RegUserSubmitBtnClicked(false);
  }


    
    ValidateForm = () => {
      this.props.ValidateForm({            
          Password: this.state.password,
          EmailId: this.state.emailAddress
      });
  }

  keyPress = (event:any) => {
      event.persist();
      if ( this.props.login.isSubmitBtnClicked ){
          this.ValidateForm();
      }
  }

  textChange = (event:any, type: string) => {
      switch(type){            
          case 'Password':
              this.setState({'password':event.target.value});
              break;
          case 'EmailId':
              this.setState({'emailAddress': event.target.value});
              break;
      }
  }




  GoToAuth = () => {
      this.props.ResetForm();
      this.props.SubmitloginBtnClicked(true);
      this.ValidateForm();
      setTimeout(() => this.SubmitForm(), 0);
  }


  handleKeyDown=(event: any) => {
    console.log(event);
     if ( event.key === 'Enter')
     {
       event.preventDefault();
       this.GoToAuth()
     }
   }


  SubmitForm = () => {
      if (this.props.login?.isSubmitBtnClicked && this.props.login?.isFormValid) {
          //this.Loader(true);
          this.props.SubmitLogin({                            
              Password: this.state.password,
              EmailId: this.state.emailAddress
          });
      }
  }

  handleSocialLogin = async (user: any,fb?:boolean) => {
     const items = {
        "AccessToken":user._token.accessToken,
        "RefreshToken": user._token.accessToken,
        "UserName":user._profile.name,
    };   
      await StorageManagement.saveUserSession(items);
    if(fb){
      this.props.SubmitUserDetails({
        UserName:user._profile.name,
        FirstName:user._profile.firstName,
        LastName: user._profile.lastName,
        Password: '',
        EmailId:user._profile.email,
        PhoneNumber: '',
        AppUser:'appuser'
      });
    }
    else{
      this.props.SubmitUserDetails({
        UserName:user._profile.name,
        FirstName:user._profile.firstName,
        LastName: user._profile.lastName,
        Password: '',
        EmailId:user._profile.email,
        PhoneNumber: '',
        AppUser:'appuser'
      });
    
    }
  }


  handleSocialLoginFailure  = (err: any) => {
    toast.error(err, {
      autoClose: false,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: false,
      progress: false,
    });
  }
  
  
  




    render() {

        if (this.state.goToAuth === true) {
            return <Redirect to={`${process.env.PUBLIC_URL}/${this.state.goToUrl}`} push={true} />
        }
        return (
          <React.Fragment>
            <Header  
             
            ></Header>
            <React.Fragment>
              <ToastContainer
                position="top-center"
                hideProgressBar={false}
                autoClose={false}
                newestOnTop={true}
                closeOnClick={false}
                draggable={false}
                rtl={false}
              />
               <div>
              <section className="breadcrumbs" style={{marginTop:-100}}>
                <div className="container">
                  <div className="d-flex justify-content-between align-items-center">
                    <h2> Sign In</h2>
                    <ol>
                      <li>
                        {" "}
                        <Link to={`${process.env.PUBLIC_URL}/`}>Home</Link>
                      </li>
                      <li> Sign In</li>
                    </ol>
                  </div>
                </div>
              </section>
              <section className="about" data-aos="fade-up">
                <div className="container">
                  <div className="row">
                  <section
            className="contact"
            data-aos="fade-up"
            data-aos-easing="ease-in-out"
            data-aos-duration="500"
          >
            <div className="container">
              <div className="row justify-content-center">
                <div className="col-lg-4 center-block" style={{lineHeight:'5px'}}>
                    <div className="info-box">
                <i className="bx bx-user"></i>
                <br></br>
                <br></br>
                <span style={{marginTop:5}}>New to this site? <Link className="col-6" to={`${process.env.PUBLIC_URL}/signup`}>Sign Up</Link> </span>
                <h3>
                    Login
                </h3>
                 <br></br>
                 <br></br>
                 <br></br>
                 <SocialButton  facebook={true}
                  provider='facebook'
                  appId='139319344636688'
                  onLoginSuccess={(e:any)=>this.handleSocialLogin(e,true)}
                  onLoginFailure={this.handleSocialLoginFailure}
                >
                      <span style={{position:'relative',bottom:4,marginLeft:5}}>
                   Login with Facebook
                  </span>
                 
                </SocialButton>
                <SocialButton facebook={false}
                  provider='google'
                  appId='971211940395-v8h48h540cpfn2ig1blqhtvdttbjh4n1.apps.googleusercontent.com'
                  onLoginSuccess={(e:any)=>this.handleSocialLogin(e,false)}
                  onLoginFailure={this.handleSocialLoginFailure}
                >
                  <span style={{position:'relative',bottom:4,marginLeft:5}}>
                  Login with Google
                  </span>
                 
                </SocialButton>
                <h3>
                    OR
                </h3>
                  <div
                    style={{boxShadow:'none'}}
                    className="php-email-form"
                  >
                    <div className="row">
                      <div className="col-md-12 form-group">
                        <input
                          type="email"
                          name="name"
                          className="form-control"
                          id="name"
                          onKeyPress={(e:any)=>this.handleKeyDown(e)}
                          placeholder="Email"
                          required={true}  onChange={(text)=>this.textChange(text,'EmailId')}   onKeyUp={(event)=>this.keyPress(event)} value={this.state.emailAddress}
                        />
                        <div className="invalid-feedback"> {this.props.login?.validationErrors?.EmailId}</div>
                      </div>
                    </div>
                    <div className="form-group mt-3">
                      <input
                      type="password"
                        className="form-control"
                        name="password"
                        id="password"
                        placeholder="Password"
                        value={this.state.password} 
                        onKeyPress={(e:any)=>this.handleKeyDown(e)}
                        onChange={(text)=>this.textChange(text,'Password')}
                        onKeyUp={(event)=>this.keyPress(event)} 
                      />
                      <div className="invalid-feedback">{this.props.login?.validationErrors?.Password}</div>
                    </div>
                    <div className="text-center mt-4">
                    <button name="submit" id="form-submit" type="submit"  onClick={this.GoToAuth} className="btn btn-md btn-black">Sign In</button>
                    </div>
                    
                
                  </div>
            
                  </div>
                </div>
              </div>
            </div>
          </section>
       
                  </div>
                </div>
              </section>
              <section className="testimonials"></section>
            </div>
            </React.Fragment>
            <Footer></Footer>
          </React.Fragment>
        );
    }
}